<?php
$update_type = $_POST['type']; //doctor or patient
if($_POST['type'] == 'chief') $update_type = 'doctor'; // chief also update info by doctor
$conn = mysqli_connect("localhost",$update_type,$update_type,"hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$update_row = '';
if(!empty($_POST["tel_num"])){
  $update_row = 'tel_num';
}
if(!empty($_POST["email"])){
  $update_row = 'email';
}
if(!empty($_POST["password"])){
  $update_row = 'password';
}
$info_update = "
    UPDATE {$update_type}
    SET {$update_row} = '{$_POST[$update_row]}'
    WHERE username='{$_POST['user']}'
";
  echo $info_update.'<br>';

  if($update_row == 'password'){
    $login_update = "
      UPDATE login
      SET password = '{$_POST['password']}'
      WHERE username='{$_POST['user']}'
    ";
    try{
      mysqli_begin_transaction($conn, MYSQLI_TRANS_START_READ_WRITE);
      mysqli_query($conn, $info_update);
      mysqli_query($conn, $login_update);
      mysqli_commit($conn);
      echo "<h1> 密码修改成功 ！</h1>";
      echo "<form action=\"{$_POST['type']}_page/{$_POST['type']}_page.php?user={$_POST['user']}&status=0.php\" method=\"post\">
        <input type=\"submit\" value=\"返回\">
        </form>";
    }
    catch(Exception $e){
      echo ' WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/{$_POST['type']}_page/{$_POST['type']}_page.php?user={$_POST['user']}&status=1");
    }
  }
  else {
    try{
      mysqli_query($conn, $info_update);
      echo "<h1> 修改成功 ！</h1>";
      echo "<form action=\"{$_POST['type']}_page/{$_POST['type']}_page.php?user={$_POST['user']}&status=0.php\" method=\"post\">
        <input type=\"submit\" value=\"返回\">
        </form>";
    }
    catch(Exception $e){
      echo ' WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/{$_POST['type']}_page/{$_POST['type']}_page.php?user={$_POST['user']}&status=1");
    }
  }
?>


<?php
$conn = mysqli_connect("localhost","root","zhenxiong","hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$login_sql = "SELECT type FROM login WHERE username='{$_POST['username']}' and password='{$_POST['password']}'";
try{
  $result = mysqli_query($conn, $login_sql);
  if($row = mysqli_fetch_array($result)){
    // echo "<h1> 登陆成功</h1>";
    // echo $row['type']."<br>".$row['id'];
    // echo "WAIT";
    if($row['type'] == 'PATIENT')
      header("Location: ../patient_page/patient_page.php?user=".$_POST['username']);
    elseif ($row['type'] == 'DOCTOR') {
      header("Location: ../doctor_page/doctor_page.php?user=".$_POST['username']);
    }
    elseif ($row['type'] == 'DBA'){
      header("Location: ../dba_page/dba_page.php?user=".$_POST['username']);
    }
    // elseif ($row['type'] == 'CHIEF') {
    //   header("Location: ../chief_page/chief_page.php?user=".$_POST['username']);
    // }
  }
  else header("Location: http://127.0.0.1/hospital.php?status=1");
}
catch(Exception $e){
    echo '// WARNING: WRONG DATA';
    error_log(mysqli_error($conn));
    header("Location: http://127.0.0.1/hospital.php?status=1");
}

?>

<!-- <form action='insert_doc_to_dept.php' method='post'>
  <fieldset>
    <legend>Add Doctor To Department of $dept?></legend>
    <input type='text' name='id' maxlength='11' placeholder='输入医生ID' required>
    <input type='hidden' name='dept' value=$dept?>>
    <input type="hidden" name='chief_id' value=$chief_id?>>
    <input type='submit' value='提交'>
  </fieldset>
</form> -->
<?php
$update_type = $_POST['type']; //chief or pg_dba\
$dept = $_POST['dept'];
$doc_id = $_POST['doc_id'];
$conn = mysqli_connect("localhost",$update_type,$update_type,"hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}

$update_doc_dept = "  UPDATE doctor
                      SET department = '{$dept}'
                      WHERE doctor_id = '{$doc_id}'
                      AND department = 'Unselected'
";
echo $update_doc_dept.'<br>';
mysqli_query($conn, $update_doc_dept);
echo "<h1> 修改成功 ！</h1>";
echo
    "<form action=\"department_update_page.php?dept={$dept}\" method=\"post\">
      <input type=\"submit\" value=\"返回\">
    </form>";
?>

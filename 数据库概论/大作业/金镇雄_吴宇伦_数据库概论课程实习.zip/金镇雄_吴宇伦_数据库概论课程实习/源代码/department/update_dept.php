<?php
$update_type = $_POST['type']; //chief or pg_dba
$dept = $_POST['dept'];
$conn = mysqli_connect("localhost",$update_type,$update_type,"hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$info_update = "
    UPDATE departments
    SET description = '{$_POST['desc']}'
    WHERE department = '{$dept}'
";
echo $info_update.'<br>';
mysqli_query($conn, $info_update);
echo "<h1> 修改成功 ！</h1>";
echo
    "<form action=\"department_update_page.php?dept={$dept}\" method=\"post\">
      <input type=\"submit\" value=\"返回\">
    </form>";
?>

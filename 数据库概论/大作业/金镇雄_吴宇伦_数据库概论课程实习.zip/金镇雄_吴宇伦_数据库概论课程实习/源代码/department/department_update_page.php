<?php
$dept = '';
$chief_name = '';
$chief_id = '';
$chief_telnum = '';
$dept_desc = '';
$unselected_doc = array();

if(isset($_GET['dept'])) {
  $dept = $_GET['dept'];
}

$conn = mysqli_connect('localhost','chief','chief','hospitaldb');
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}

$desc_sql = "SELECT description, chief_id FROM departments WHERE department='{$dept}'";
$desc_result = mysqli_query($conn, $desc_sql);
if($desc_row = mysqli_fetch_array($desc_result)){
    $dept_desc = $desc_row['description'];
    $chief_id = $desc_row['chief_id'];
}

$chief_sql= "SELECT name, tel_num
             FROM doctor
             WHERE doctor_id='{$chief_id}'
            ";// chief name and tel_num;
$chief_result = mysqli_query($conn, $chief_sql);
if($chief_row = mysqli_fetch_array($chief_result)){
  $chief_name = $chief_row['name'];
  $chief_telnum = $chief_row['tel_num'];
}

$unselected_doc_sql = "SELECT doctor_id FROM doctor WHERE department = 'Unselected'";
// echo $department_sql;
$doc_result = mysqli_query($conn, $unselected_doc_sql);
if($doc_result){
    while($row = mysqli_fetch_array($doc_result)){
      array_push($unselected_doc, $row['doctor_id']);
    }
}
?>

<form action='/../doctor_page/doctor_page.php' method='post'>
    <input type='hidden' name='id' value='<?=$chief_id?>'>
    <input type='submit' value='返回'>
</form>

<h1>Department of <?=$dept?></h1>

<h4><?=$dept_desc?></h4>

<form action='update_dept.php' method='post'>
  <p><textarea maxlength='1024' cols='50' rows='10' name='desc' placeholder='<?=$dept_desc?>' required> </textarea></p>
  <input type='hidden' name='dept' value='<?=$dept?>'>
  <input type='hidden' name='type' value='chief'>
  <input type='submit' value='修改'>
</form>

科长姓名: <?=$chief_name?><br>
科长电话: <?=$chief_telnum?><br>

<h3>下属医生</h3>

<form action='insert_doc_to_dept.php' method='post'>
  <fieldset>
    <legend>Add Doctor To Department of <?=$dept?></legend>
    <label for="Unselected_Doc">医生ID</label>
        <select name="doc_id">
           <option value="">--- 选择ID ---</option>
           <?php
              for ($i=0; $i < count($unselected_doc); $i++) {
                echo "<option value=".$unselected_doc[$i].">".$unselected_doc[$i]."</option>";
              }
           ?>
        </select>
    <input type='hidden' name='dept' value=<?=$dept?>>
    <input type='hidden' name='type' value='chief'>
    <input type='submit' value='提交'>
  </fieldset>
</form>

<?php
$doctor_sql= "SELECT *
             FROM doctor
             WHERE department='{$dept}'
            ";
$doctor_result = mysqli_query($conn, $doctor_sql);
while($doctor_row = mysqli_fetch_array($doctor_result)){
    $id=$doctor_row['doctor_id'];
    $degree=$doctor_row['degree'];
    echo "<form action='update_doc_of_dept.php' method='post'>
      <fieldset>
        <legend>".$doctor_row['name']."</legend>
        ID: $id<br>
        登录名: {$doctor_row['username']}<br>
        性别: {$doctor_row['sex']}<br>
        出生年月日: {$doctor_row['birthdate']}<br>
        电话: {$doctor_row['tel_num']}<br>
        电子邮件: {$doctor_row['email']}<br>
        <div>
          <label for='name'>毕业院校: </label>
          <input type='text' name='graduate' value='".$doctor_row['graduate']."' maxlength='32' required>
          <input type='hidden' name='id' value=".$id.">

        </div>
        <div>
          <label for='name'>学位: </label>
          <fieldset>
            <legend></legend>
              <p>
              Post<input type='radio' name='degree' value='1'"; if($degree == 'Post')echo "checked"; echo ">
              Doctor<input type='radio' name='degree' value='2'"; if($degree == 'Doctor')echo "checked"; echo ">
              Master<input type='radio' name='degree' value='3'"; if($degree == 'Master')echo "checked"; echo ">
              Bachelor<input type='radio' name='degree' value='4'"; if($degree == 'Bachelor')echo "checked"; echo ">
              Junior<input type='radio' name='degree' value='5'"; if($degree == 'Junior')echo "checked"; echo ">
              </p>
          </fieldset>


        </div>
        <div>
          <label for='name'>技术职称: </label>
          <input type='text' name='title' value='".$doctor_row['title']."' maxlength='32' required>
        </div>
        <div>
          <label for='name'>技术特长: </label>
          <input type='text' name='specialty' value='".$doctor_row['specialty']."' maxlength='256' required>
        </div>
        <div><input type='hidden' name='dept' value={$dept}></div>
        <div><input type='hidden' name='id' value={$id}></div>
        <div><input type='hidden' name='type' value='chief'></div>
        <div><input type='submit' value='修改'></div>
      </fieldset>
    </form>";
    if($doctor_row['is_chief'] == '0'){
      echo "<form action='delete_doc_from_dept.php' method='post'>
              <input type='hidden' name='id' value={$id}>
              <input type='hidden' name='dept' value={$dept}>
              <input type='hidden' name='type' value='chief'>
              <input type='submit' value='删除'>
            </form>
            ";
    }

}
?>

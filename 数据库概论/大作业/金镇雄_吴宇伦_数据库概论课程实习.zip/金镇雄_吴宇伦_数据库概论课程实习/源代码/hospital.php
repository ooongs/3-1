
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>HomePage</title>
  </head>
  <body>
    <h1>404医院</h1>
    <form action="/login/login.php" method="post">
      <p><input type="text" name="username" placeholder="登录名" maxlength="15" required> </p>
      <p><input type="password" name="password" placeholder="密码" maxlength="20" required> </p>
      <input type="submit">
    </form>
    <?php
      if(isset($_GET['status']) && $_GET['status']=='1'){
        echo "WRONG USERNAME OR PASSWORD";
      }
    ?>
    <p><a href="/create_account/create_account_page.php?status=0">CREATE ACCOUNT</a></p>
  </body>
</html>

<?php
$dept = $_POST['dept'];
$user = $_POST['user'];
$chief_id = $_POST['chief_id'];
$conn = mysqli_connect("localhost",'dba','dba',"hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$update_chief = "
UPDATE doctor
SET is_chief = 0
WHERE doctor_id = {$chief_id}
";
$update_doc = "
  UPDATE doctor
  SET department = 'Unselected'
  WHERE department = '{$dept}'
";
$delete_dept = "
    DELETE FROM departments
    WHERE department = '{$dept}'
";
try{
  echo $update_chief."<br>";
  echo $update_doc."<br>";
  echo $delete_dept."<br>";
  mysqli_begin_transaction($conn, MYSQLI_TRANS_START_READ_WRITE);
  mysqli_query($conn,$update_chief);
  mysqli_query($conn,$update_doc);
  mysqli_query($conn,$delete_dept);
  mysqli_commit($conn);
}
catch(Exception $e){
      mysqli_rollback($conn);
      echo ' WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/dba_page/add_delete_department_page.php?status=1");
}
echo "<h1> 删除成功 ！</h1>";
echo
  "<form action=\"add_delete_department_page.php\" method=\"post\">
    <input type=\"submit\" value=\"返回\">
    <input type='hidden' name='user' value='{$user}'>
  </form>";
?>

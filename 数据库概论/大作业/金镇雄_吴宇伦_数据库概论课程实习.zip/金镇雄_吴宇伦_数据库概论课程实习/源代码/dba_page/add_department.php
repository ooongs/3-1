<?php
$dept = $_POST['dept'];
$doc_id = $_POST['doc_id'];
$desc = $_POST['desc'];
$user = $_POST['user'];
$conn = mysqli_connect("localhost",'dba','dba',"hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$add_department = "
    INSERT INTO departments (department,description,chief_id)
    VALUE ('{$dept}','{$desc}',{$doc_id})
";
$doctor_update = "
    UPDATE doctor
    SET department = '{$dept}', is_chief = 1
    WHERE doctor_id = '{$doc_id}'
";
  try{
    echo $add_department."<br>";
    echo $doctor_update."<br>";
    mysqli_begin_transaction($conn, MYSQLI_TRANS_START_READ_WRITE);
    mysqli_query($conn,$add_department);
    mysqli_query($conn,$doctor_update);
    mysqli_commit($conn);
  }
  catch(Exception $e){
        mysqli_rollback($conn);
        echo ' WARNING: WRONG DATA';
        error_log(mysqli_error($conn));
        header("Location: http://127.0.0.1/dba_page/add_delete_department_page.php?status=1");
  }
echo "<h1> 修改成功 ！</h1>";
echo
    "<form action=\"add_delete_department_page.php\" method=\"post\">
      <input type=\"submit\" value=\"返回\">
      <input type='hidden' name='user' value='{$user}'>
    </form>";
?>

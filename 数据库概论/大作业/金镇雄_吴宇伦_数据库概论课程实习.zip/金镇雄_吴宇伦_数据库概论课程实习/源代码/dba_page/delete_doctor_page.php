<?php
$user = 'dba1';
if(isset($_GET['user'])) $user = $_GET['user'];
if(!empty($_POST['user'])) $user = $_POST['user'];
echo "<form action='../dba_page/dba_page.php?user={$user}' method=\"post\">
  <input type=\"submit\" value=\"返回\">
</form>";
$conn = mysqli_connect('localhost','chief','chief','hospitaldb');
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
if(isset($_GET['status']) && $_GET['status'] == 1)
  echo "DELETE DOCTOR FAILED";
$doc_sql = "SELECT name,doctor_id,tel_num,department,username FROM doctor";
$doc_result = mysqli_query($conn,$doc_sql);
while($doc_row = mysqli_fetch_array($doc_result)){
  ?>
  <fieldset>
    姓名: <?=$doc_row['name']?> <br>
    <legend>医生ID: <?=$doc_row['doctor_id']?></legend>
    电话: <?=$doc_row['tel_num']?> <br>
    科室: <?=$doc_row['department']?> <br>
    <form action="delete_doctor.php" method="post">
      <input type="hidden" name="user" value="<?=$user?>">
      <input type="hidden" name="doc_user" value="<?=$doc_row['username']?>">
      <input type="submit" value="删除">
    </form>
  </fieldset>
  <?php
}
?>

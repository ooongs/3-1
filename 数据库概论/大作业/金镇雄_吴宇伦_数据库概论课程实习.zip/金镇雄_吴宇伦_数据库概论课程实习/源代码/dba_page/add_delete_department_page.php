<?php
$user = 'dba1';
if(isset($_GET['user'])) $user = $_GET['user'];
if(!empty($_POST['user'])) $user = $_POST['user'];
echo "<form action='../dba_page/dba_page.php?user={$user}' method=\"post\">
  <input type=\"submit\" value=\"返回\">
</form>";
$conn = mysqli_connect('localhost','chief','chief','hospitaldb');
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$doc_id = array();
$doc_name = array();
$doc_dept = array();
$doc_sql = "SELECT doctor_id,name,department FROM doctor WHERE is_chief = 0";
// echo $department_sql;
$doc_result = mysqli_query($conn, $doc_sql);
if($doc_result){
    while($row = mysqli_fetch_array($doc_result)){
      array_push($doc_id, $row['doctor_id']);
      array_push($doc_name, $row['name']);
      array_push($doc_dept, $row['department']);
    }
}
?>

<form action="add_department.php" method="post">
  <fieldset>
    <legend>ADD DEPARTMENT</legend>
    <input type="text" name="dept" placeholder="科室名">
    <p><textarea maxlength='1024' cols='50' rows='10' name='desc' required> </textarea></p>
    <input type="hidden" name="user" value="<?=$user?>">
    <select name="doc_id">
        <option value="">------- 选择ID -------</option>
            <?php
              for ($i=0; $i < count($doc_id); $i++) {
                echo "<option value=".$doc_id[$i].">".$doc_id[$i].": ".$doc_name[$i]."-".$doc_dept[$i]."</option>";
              }
               ?>
    </select>
    <input type='submit' value='提交'>
  </fieldset>
</form>
<?php
if(isset($_GET['status']) && $_GET['status'] == 1)
  echo "ADD DEPARTMENT FAILED";
$department_sql = "SELECT * FROM department_view";
$dept_result = mysqli_query($conn,$department_sql);
while($dept_row = mysqli_fetch_array($dept_result)){
  ?>
  <fieldset>
    <legend><?=$dept_row['department']?></legend>
    科长ID: <?=$dept_row['chief_id']?> <br>
    科长姓名: <?=$dept_row['chief_name']?> <br>
    科长电话: <?=$dept_row['chief_tel']?> <br>
    科室描述: <?=$dept_row['description']?> <br>
    <form action="delete_department.php" method="post">
      <input type="hidden" name="user" value="<?=$user?>">
      <input type='hidden' name='dept' value="<?=$dept_row['department']?>">
      <input type="hidden" name="chief_id" value="<?=$dept_row['chief_id']?>">
      <input type="submit" value="删除">
    </form>
  </fieldset>
  <?php
}
?>


<?php
$user = $_POST['user'];
$doc_user = $_POST['doc_user'];
$conn = mysqli_connect("localhost",'dba','dba',"hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$delete_login = "
  DELETE FROM login
  WHERE type='DOCTOR' AND username = '{$doc_user}'
";
$delete_doctor = "
    DELETE FROM doctor
    WHERE username = '{$doc_user}'
";
try{
  echo $delete_login."<br>";
  echo $delete_doctor."<br>";
  mysqli_begin_transaction($conn, MYSQLI_TRANS_START_READ_WRITE);
  mysqli_query($conn,$delete_login);
  mysqli_query($conn,$delete_doctor);
  mysqli_commit($conn);
}
catch(Exception $e){
      mysqli_rollback($conn);
      echo ' WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/dba_page/delete_doctor_page.php?status=1");
}
echo "<h1> 删除成功 ！</h1>";
echo
  "<form action=\"delete_doctor_page.php\" method=\"post\">
    <input type=\"submit\" value=\"返回\">
    <input type='hidden' name='user' value='{$user}'>
  </form>";
?>

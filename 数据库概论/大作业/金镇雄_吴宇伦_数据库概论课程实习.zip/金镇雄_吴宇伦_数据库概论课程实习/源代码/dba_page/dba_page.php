
<form action='/../hospital.php' method='post'>
  <input type='submit' value='退出登录'>
</form>
<form action='add_delete_department_page.php' method='post'>
  <input type="hidden" name="user" value="<?=$_GET['user']?>">
  <input type='submit' value='科室增删'>
</form>
<form action='/../create_account/create_doctor_account_page.php' method='post'>
  <input type="hidden" name="user" value="<?=$_GET['user']?>">
  <input type='submit' value='医生注册'>
</form>
<form action='delete_doctor_page.php' method='post'>
  <input type="hidden" name="user" value="<?=$_GET['user']?>">
  <input type='submit' value='医生删除'>
</form>
<form action='sql/sql1.php' method='post'>
  <input type="hidden" name="user" value="<?=$_GET['user']?>">
  <input type='submit' value=
  '找出2021年1月1日之后来院就诊次数前十的患者，按照就诊次数进行降序排序；若次数相同，则按照患者姓名拼音次序排序'>
</form>
<form action='sql/sql2.php' method='post'>
  <input type="hidden" name="user" value="<?=$_GET['user']?>">
  <input type='submit' value=
  '查找开具病历和处方数量最多的医生的信息，包括医生的姓名、所属科室、开具病历数量、开具处方数量，按照开具病历和处方进行降序排序，病历数相同的，按照处方数排序'>
</form>
<form action='sql/sql3.php' method='post'>
  <input type="hidden" name="user" value="<?=$_GET['user']?>">
  <input type='submit' value=
  '找出在30天内接诊病人数量少于全医院医生平均接诊数量的医生姓名、所属科室'>
</form>
<form action='sql/sql4.php' method='post'>
  <input type="hidden" name="user" value="<?=$_GET['user']?>">
  <input type='submit' value=
  '找出在14天内接诊过体温高于37.3度的病人的科室'>
</form>
<form action='sql/sql5.php' method='post'>
  <input type="hidden" name="user" value="<?=$_GET['user']?>">
  <input type='submit' value=
  '找出在14天内接诊过体温高于37.找出在7天内所有医生开具的处方中，开具数量总数最少的药物名称，若存在多种药物的总数相同且最少，则都列出'>
</form>
<form action='sql/sql6.php' method='post'>
  <input type="hidden" name="user" value="<?=$_GET['user']?>">
  <input type='submit' value=
  '找出在30天内爽约次数超过2次的患者（系统中存在其预约记录，但是没有相应的病历和处方）的姓名和身份证号'>
</form>

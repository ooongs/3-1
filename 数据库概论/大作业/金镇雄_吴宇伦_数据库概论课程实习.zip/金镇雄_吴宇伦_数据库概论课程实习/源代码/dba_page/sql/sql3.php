<?php
$user = $_POST['user'];
echo "<h3>找出在30天内接诊病人数量少于全医院医生平均接诊数量的医生姓名、所属科室</h3>";
$conn = mysqli_connect("localhost",'dba','dba',"hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}

$sql = "
select name, department
from (select doctor_id, name, department
		from doctor) as a
	natural join
	(select doctor_id, count(*) as patient_num
		from medical_record
		where diagnosed_time > date_sub(curdate(), interval 30 day)
		group by doctor_id
        having patient_num < avg(patient_num)) as b;
";


  $result = mysqli_query($conn,$sql);
  while($row = mysqli_fetch_array($result)){
    ?>
    <fieldset>
      姓名: <?=$row['name']?><br>
      科室: <?=$row['department']?><br>
    </fieldset>
    <?php
  }
try{}
catch(Exception $e){
      mysqli_rollback($conn);
      echo ' WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/dba_page/dba_page.php?user={$user}&status=1");
}

echo
  "<form action='../dba_page.php?user={$user}' method=\"post\">
    <input type=\"submit\" value=\"返回\">
  </form>";
?>

<?php
$user = $_POST['user'];
echo "<h3>找出2021年1月1日之后来院就诊次数前十的患者，按照就诊次数进行降序排序；若次数相同，则按照患者姓名拼音次序排序 </h3>";
$conn = mysqli_connect("localhost",'dba','dba',"hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$temp_sql = "
create temporary table patient_record_num as(
	select patient_id, count(*) as record_num
	from medical_record
	where date(diagnosed_time) >= '2021-1-1'
	group by patient_id
);
";
$sql = "
select name
from patient natural join patient_record_num
order by record_num desc, name asc
limit 10;
";


try{
  mysqli_begin_transaction($conn, MYSQLI_TRANS_START_READ_WRITE);
  mysqli_query($conn,$temp_sql);
  $result = mysqli_query($conn,$sql);
  while($row = mysqli_fetch_array($result)){
    echo "<p>".$row['name']."</p>";
  }
  mysqli_commit($conn);

}
catch(Exception $e){
      mysqli_rollback($conn);
      echo ' WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/dba_page/dba_page.php?user={$user}&status=1");
}

echo
  "<form action='../dba_page.php?user={$user}' method=\"post\">
    <input type=\"submit\" value=\"返回\">
  </form>";
?>

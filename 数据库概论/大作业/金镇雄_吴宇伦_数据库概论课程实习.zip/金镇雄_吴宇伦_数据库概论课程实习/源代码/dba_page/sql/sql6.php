<?php
$user = $_POST['user'];
echo "<h3>找出在30天内爽约次数超过2次的患者（系统中存在其预约记录，但是没有相应的病历和处方）的姓名和身份证号</h3>";
$conn = mysqli_connect("localhost",'dba','dba',"hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}

$sql = "
select name, id_card_num
from patient
where patient_id in
	(select patient_id
		from appointment
		where finish = false
			and now() > time
			and time > date_sub(curdate(), interval 30 day)
		group by patient_id
        having count(*) > 2)
";


  $result = mysqli_query($conn,$sql);
$flag = 0;
  while($row = mysqli_fetch_array($result)){
    $flag = 1;
    ?>
    <fieldset>
      姓名: <?=$row['name']?><br>
      身份证号: <?=$row['id_card_num']?><br>
    </fieldset>
    <?php
  }
  if($flag == 0){
    echo "<h4>无</h4>";
  }
try{}
catch(Exception $e){
      mysqli_rollback($conn);
      echo ' WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/dba_page/dba_page.php?user={$user}&status=1");
}

echo
  "<form action='../dba_page.php?user={$user}' method=\"post\">
    <input type=\"submit\" value=\"返回\">
  </form>";
?>

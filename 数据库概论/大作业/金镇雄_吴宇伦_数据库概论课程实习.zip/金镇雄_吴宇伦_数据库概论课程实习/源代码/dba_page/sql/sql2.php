<?php
$user = $_POST['user'];
echo "<h3>查找开具病历和处方数量最多的医生的信息，包括医生的姓名、所属科室、开具病历数量、开具处方数量，按照开具病历和处方进行降序排序，病历数相同的，按照处方数排序</h3>";
$conn = mysqli_connect("localhost",'dba','dba',"hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}

$sql = "
select a.name as name, a.department as department, b.record_num as record_num, c.recipe_num as recipe_num
from (select doctor_id, name, department
		from doctor) as a
	natural join
    (select doctor_id, count(*) as record_num
		from medical_record
        group by doctor_id) as b
    natural join
    (select doctor_id, count(*) as recipe_num
		from medical_record
        where record_id in (select distinct record_id from recipes)
        group by doctor_id) as c
order by record_num desc, recipe_num desc;
";


  $result = mysqli_query($conn,$sql);
  while($row = mysqli_fetch_array($result)){
    ?>
    <fieldset>
      <legend><?=$row['name']?></legend>
      科室: <?=$row['department']?><br>
      病历数量: <?=$row['record_num']?><br>
      处方数量: <?=$row['recipe_num']?><br>
    </fieldset>
    <?php
  }
try{}
catch(Exception $e){
      mysqli_rollback($conn);
      echo ' WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/dba_page/dba_page.php?user={$user}&status=1");
}

echo
  "<form action='../dba_page.php?user={$user}' method=\"post\">
    <input type=\"submit\" value=\"返回\">
  </form>";
?>

<?php
$user = $_POST['user'];
echo "<h3>找出在14天内接诊过体温高于37.找出在7天内所有医生开具的处方中，开具数量总数最少的药物名称，若存在多种药物的总数相同且最少，则都列出</h3>";
$conn = mysqli_connect("localhost",'dba','dba',"hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}


$sql = "
select medicine_name
from (select medicine_name, sum(medicine_num) as total_num
		from (select record_id
				from medical_record
				where diagnosed_time > date_sub(curdate(), interval 7 day)) as a
			natural join recipes
		group by medicine_name
		having total_num = min(total_num)) as b;
";

try{
  $result = mysqli_query($conn,$sql);
  while($row = mysqli_fetch_array($result)){
    ?>
    <fieldset>
      药名: <?=$row['medicine_name']?><br>
    </fieldset>
    <?php
  }
}
catch(Exception $e){
      mysqli_rollback($conn);
      echo ' WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/dba_page/dba_page.php?user={$user}&status=1");
}

echo
  "<form action='../dba_page.php?user={$user}' method=\"post\">
    <input type=\"submit\" value=\"返回\">
  </form>";
?>

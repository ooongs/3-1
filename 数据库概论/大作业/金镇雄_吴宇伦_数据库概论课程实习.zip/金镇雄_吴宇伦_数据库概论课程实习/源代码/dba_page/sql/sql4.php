<?php
$user = $_POST['user'];
echo "<h3>找出在14天内接诊过体温高于37.3度的病人的科室</h3>";
$conn = mysqli_connect("localhost",'dba','dba',"hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}

$sql = "
select distinct(department)
from doctor as D, appointment as A
where D.doctor_id = A.doctor_id
	and A.temperature > 37.0
    and A.time > date_sub(curdate(), interval 14 day);
";


  $result = mysqli_query($conn,$sql);
  while($row = mysqli_fetch_array($result)){
    ?>
    <fieldset>
      科室: <?=$row['department']?><br>
    </fieldset>
    <?php
  }
try{}
catch(Exception $e){
      mysqli_rollback($conn);
      echo ' WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/dba_page/dba_page.php?user={$user}&status=1");
}

echo
  "<form action='../dba_page.php?user={$user}' method=\"post\">
    <input type=\"submit\" value=\"返回\">
  </form>";
?>

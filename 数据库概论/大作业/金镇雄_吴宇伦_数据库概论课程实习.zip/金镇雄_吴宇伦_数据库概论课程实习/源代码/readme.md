##### 404医院数据管理系统文件介绍：

- /hospital.php： 登录界面提示输入用户名和密码。界面中的CREATE_ACCOUNT链接提供注册功能；
- /login，进行用户名和密码的验证，同时验证类型（即数据库管理员、科长、医生、患者），根据不同的类型进入不同的界面。 
- /dba_page：数据库管理员的页面，能进行科室增删、医生注册、医生删除以及要求4提到的各种查询操作，分别在 add_delete_department_page.php、create_account/create_account_page.php、delete_doctor_page.php、/sql/sql1~sq6.php 完成。所有后端操作是文件名中不包括page的文件中执行的。
- /doctor_page：医生和科长页面，显示医生的个人信息及查看预约和病历/处方的可执行操作。编写病历和处方在create_medical_record.php完成，可以从search_appointment.php 页面跳转到此页面。登录时判断是否为科长，若是，则可执行管理科室、查看下属医生病历与处方等功能，分别在/department文件夹和chief_search_doc_mr.php 完成。属于发热门诊的医生，根据患者需求，在确认无新冠肺炎感染情况下，将患者转诊到其它科室，在fever_appointment_check.php 完成。
- /patient_page：患者页面，可执行查看科室、预约挂号、缴费、查看病历、查看预约记录等操作
- /department：医生科室管理操作在此文件加中执行
- /info_update.php：用于患者以及医生的个人信息（电话、电子邮件及密码）修改，每个用户在其个人信息页面中可以直接输入其个人信息后提交给此文件，在此文件中进行对patient表或doctor表的修改 
- /create_account：所有的注册功能在此文件夹中，包括患者、医生和科长的注册

##### 小组分工情况

金镇雄：登录与注册页面，系统管理员相关页面，医生用户相关页面，患者个人信息主页，readme文档，测试数据，视图，数据库权限

吴宇伦：患者查询医生信息、填写流调表及预约页面，患者查看预约和诊断记录页面，ER图，关系模式表，数据库表、触发器、查询语句，设计文档
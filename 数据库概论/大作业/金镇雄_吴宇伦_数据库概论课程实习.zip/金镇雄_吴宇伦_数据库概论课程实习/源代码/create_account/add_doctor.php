<?php
$conn = mysqli_connect("localhost","doctor","doctor","hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$type = 1; // doctor
if(isset($_POST['is_chief']) && $_POST['is_chief']==1){
  $type = 4; // chief
}
$doctor_insert = "
  INSERT INTO doctor
    (name,id_card_num,birthdate,sex,tel_num,email,username,password,department,graduate,degree,title,specialty,is_chief)
    VALUE(
      '{$_POST['name']}','{$_POST['id_card_num']}','{$_POST['birthdate']}',{$_POST['sex']},
      '{$_POST['tel_num']}','{$_POST['email']}','{$_POST['username']}','{$_POST['password']}',
      '{$_POST['department']}','{$_POST['graduate']}',{$_POST['degree']},'{$_POST['title']}',
      '{$_POST['specialty']}',{$_POST['is_chief']}
    );
";
$login_insert = "
    INSERT INTO login
      (username,password,type)
      VALUE('{$_POST['username']}','{$_POST['password']}',$type)
";

  try{
    echo $doctor_insert."<br>";
    echo $login_insert."<br>";
    mysqli_begin_transaction($conn, MYSQLI_TRANS_START_READ_WRITE);
    mysqli_query($conn,$doctor_insert);
    mysqli_query($conn,$login_insert);
    mysqli_commit($conn);
  }
  catch(Exception $e){
        mysqli_rollback($conn);
        echo ' WARNING: WRONG DATA';
        error_log(mysqli_error($conn));
        header("Location: http://127.0.0.1/create_account/create_doctor_account_page.php?status=1");
  }
   echo "<h1> 注册成功！</h1>";
?>

  <form action="/../dba_page/dba_page.php?user=<?=$_POST['user']?>" method="post">
       <input type="submit" value="返回">
 </form>

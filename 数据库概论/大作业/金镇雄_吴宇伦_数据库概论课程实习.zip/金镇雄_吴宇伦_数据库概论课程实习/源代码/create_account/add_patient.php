<?php
$conn = mysqli_connect("localhost","patient","patient","hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$patient_insert = "
  INSERT INTO patient
    (name,id_card_num,birthdate,sex,tel_num,email,username,password)
    VALUE(
      '{$_POST['name']}','{$_POST['id_card_num']}','{$_POST['birthdate']}',{$_POST['sex']},
      '{$_POST['tel_num']}','{$_POST['email']}','{$_POST['username']}','{$_POST['password']}'
    );
";
  $login_insert = "
    INSERT INTO login
      (username,password,type)
      VALUE('{$_POST['username']}','{$_POST['password']}',2);
  ";


  try{
    mysqli_begin_transaction($conn, MYSQLI_TRANS_START_READ_WRITE);
    mysqli_query($conn,$patient_insert);
    mysqli_query($conn,$login_insert);
    mysqli_commit($conn);
  }
  catch(Exception $e){
        mysqli_rollback($conn);
        echo ' WARNING: WRONG DATA';
        error_log(mysqli_error($conn));
        header("Location: http://127.0.0.1/create_account/create_account_page.php?status=1");
  }
  echo $patient_insert."<br>".$login_insert."<br>";
   echo "<h1> 注册成功！</h1>";
?>

  <form action="/../hospital.php" method="post">
       <input type="submit" value="返回">
 </form>

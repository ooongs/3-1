<?php
$user = 'dba1';
if(isset($_GET['user'])) $user = $_GET['user'];
if(!empty($_POST['user'])) $user = $_POST['user'];
echo "<form action='/../dba_page/dba_page.php?user={$user}' method=\"post\">
  <input type=\"submit\" value=\"返回\">
</form>";
$departments = array();
try {
  $conn = mysqli_connect("localhost","dba",'dba',"hospitaldb");
  if(mysqli_connect_errno()){
    echo mysqli_correct_error();
  }
  $department_sql = "SELECT department FROM departments";
  // echo $department_sql;
  $result = mysqli_query($conn, $department_sql);
  if($result){
      while($row = mysqli_fetch_array($result)){
        array_push($departments, $row['department']);
      }
  }
} catch (Exception $e) {
    header("Location: http://127.0.0.1/hospital.php?status=1");
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Create Doctor Account</title>
  </head>
  <body>
    <h1>CREATE DOCTOR ACCOUNT</h1>
      <form action="add_doctor.php" method="post">
        <p><input type="text" name="name" placeholder="姓名" maxlength="50" required> </p>
        <p><input type="text" name="id_card_num" placeholder="身份证号" minlength="18" maxlength="18" required> </p>
        <p><input type="date" name="birthdate" placeholder="出生年月日" value="2000-01-01" required></p>
        <fieldset>
         <legend>性别</legend>
         <p>
            男<input type="radio" name="sex" value="1" checked>
            女<input type="radio" name="sex" value="2">
         </p>
      </fieldset>
        <p><input type="text" name="tel_num" placeholder="联系方式" maxlength="11" minlength="11" required> </p>
        <p><input type="email" name="email" placeholder="邮箱" maxlength="256"> </p>
        <p><input type="text" name="username" placeholder="登录名" maxlength="15" required> </p>
        <p><input type="password" name="password" placeholder="密码" maxlength="20" required> </p>
        <p><input type="text" name="graduate" placeholder="毕业院校" maxlength="32" required> </p>
        <p><input type="text" name="title" placeholder="技术职称" maxlength="32" required> </p>
        <p><input type="text" name="specialty" placeholder="技术特长" maxlength="256" required> </p>
        <fieldset>
         <legend>学位</legend>
         <p>
            Post<input type="radio" name="degree" value="1" checked>
            Doctor<input type="radio" name="degree" value="2">
            Master<input type="radio" name="degree" value="3">
            Bachelor<input type="radio" name="degree" value="4">
            Junior<input type="radio" name="degree" value="5">
         </p>
        </fieldset>
        <label for="department">科室</label>
            <select name="department" id="department">
               <option value="Unselected">--- 选择科室 ---</option>
               <?php
                  for ($i=0; $i < count($departments); $i++) {
                    echo "<option value=".$departments[$i].">".$departments[$i]."</option>";
                  }
               ?>
            </select>
        <fieldset>
         <legend>是否为科长</legend>
         <p>
            否<input type="radio" name="is_chief" value="0" checked>
            是<input type="radio" name="is_chief" value="1">
         </p>
      </fieldset>
      <input type='hidden' name="user" value="<?=$user?>">
      <input type="submit">
      </form>
      <p>
        <?php
        if(isset($_GET['status']) && $_GET['status']=='1') echo '<h3>FAILED TO CREATE ACCOUNT</h3>';
        ?>
      </p>
  </body>
</html>

<?php
$id='';
if(!empty($_POST['id'])) $id=$_POST['id'];
echo "<form action=\"/../patient_page/patient_page.php?id={$id}\" method=\"post\">
        <input type=\"submit\" value=\"返回\">
      </form>";

$conn = mysqli_connect("localhost","patient","patient","hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$record_sql = "SELECT * FROM medical_record WHERE patient_id='{$id}' ORDER BY diagnosed_time DESC";
$result = mysqli_query($conn, $record_sql);
if (mysqli_num_rows($result) <= 0){
  echo "无就诊记录";
}
while($row = mysqli_fetch_array($result)){
?>
    <fieldset>
    <form method="post" action="/../patient_page/patient_page.php?id={$id}">
      诊断: <?php echo $row['diagnosis'];?>
      <br>
      时间: <?php echo $row['diagnosed_time'];?>
      <br>
      医生: <?php echo $row['doctor_name'];?>
      <br>
      处方:
<?php
      $recipe_sql = "SELECT * FROM (SELECT medicine_name, medicine_num FROM recipes WHERE record_id = {$row['record_id']}) AS a NATURAL JOIN medicine";
      $recipe_res = mysqli_query($conn, $recipe_sql);
      if(mysqli_num_rows($recipe_res) <= 0){
        echo "无";
      } else{
        $fee = 0;
        while($medi = mysqli_fetch_array($recipe_res)){
          $fee += $medi['medicine_num'] * $medi['medicine_price'];
          echo $medi['medicine_name'].': '.$medi['medicine_num'].";";
        }
        echo "<br>费用: ".$fee;
      }
?>
      <br>
      <!--<input type="hidden" name="rid" value="<?php echo $row['record_id'];?>">-->
<?php
      if(!$row['paid'])
        echo "<input type=\"submit\" name=\"submit\" value=\"缴费\">";
?>
    </form>
    </fieldset>
<?php
}
?>

<html>
<head>
<meta charset="utf-8">
<title>预约记录</title>
<style>
.error {color: #FF0000;}
.finished {color: #00FF00;}
</style>
</head>
<body>

<?php
$id='';
if(!empty($_POST['id'])) $id=$_POST['id'];
echo "<form action=\"/../patient_page/patient_page.php?id={$id}\" method=\"post\">
        <input type=\"submit\" value=\"返回\">
      </form>";

$conn = mysqli_connect("localhost","patient","patient","hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$record_sql = "SELECT * FROM (SELECT time, doctor_id, finish FROM appointment WHERE patient_id={$id}) AS a NATURAL JOIN (SELECT doctor_id, name, department FROM doctor) AS b ORDER BY time DESC";
$result = mysqli_query($conn, $record_sql);
if (mysqli_num_rows($result) <= 0){
  echo "无预约记录";
} else {
	echo "<table border=\"1\">
			<tr>
    			<th>状态</th>
    			<th>科室</th>
				<th>医生</th>
				<th>时间</th>
  			</tr>";
	while($row = mysqli_fetch_array($result)){
		$sta = "";
		if($row['finish'])
        	$sta = "已完成";
		else if(strtotime($row['time']) <= time())
			$sta = "<span class=\"error\">已逾期</span>";
		else
			$sta = "<span class=\"finished\">待完成</span>";
		echo "<tr>
    			<td>".$sta."</td>
    			<td>".$row['department']."</td>
				<td>".$row['name']."</td>
				<td>".$row['time']."</td>
  			</tr>";
	}
	echo "</table>";
}
?>
</body>
</html>

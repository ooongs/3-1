<?php
$id='';
if(!empty($_POST['id'])) $id=$_POST['id'];
echo "<form action=\"/../patient_page/patient_page.php?id={$id}\" method=\"post\">
        <input type=\"submit\" value=\"返回\">
      </form>";
$conn = mysqli_connect("localhost","patient","patient","hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$department = !empty($_POST['department'])?$_POST['department']:'';
if($department){
  $chief_name = '';
  $chief_id = '';
  $chief_telnum = '';
  $dept_desc = '';

  $desc_sql = "SELECT description, chief_id FROM departments WHERE department='{$department}'";
  $desc_result = mysqli_query($conn, $desc_sql);
  if($desc_row = mysqli_fetch_array($desc_result)){
      $dept_desc = $desc_row['description'];
      $chief_id = $desc_row['chief_id'];
  }

  $chief_sql= "SELECT name, tel_num
               FROM doctor
               WHERE doctor_id='{$chief_id}'
              ";// chief name and tel_num;
  $chief_result = mysqli_query($conn, $chief_sql);
  if($chief_row = mysqli_fetch_array($chief_result)){
    $chief_name = $chief_row['name'];
    $chief_telnum = $chief_row['tel_num'];
  }
   $doctor_sql = "SELECT * FROM doctor WHERE department = '{$department}'";
   try{
      $result = mysqli_query($conn, $doctor_sql);
      if (mysqli_num_rows($result) <= 0)
         header("Location: http://127.0.0.1/patient_page/patient_page.php?id={$id}&status=1");
   }
   catch(Exception $e){
      echo '// WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/patient_page/patient_page.php?id={$id}&status=1");
   }
?>
   <h1>Department of <?=$department?></h1>

   <h4><?=$dept_desc?></h4>


   科长姓名: <?=$chief_name?><br>
   科长电话: <?=$chief_telnum?><br>

   <h3>下属医生</h3>
<?php
   while($row = mysqli_fetch_array($result)){
?>
    <fieldset>
      <legend><?php echo $row['name'];?></legend>
      职称: <?php echo $row['title'];?>
      <br>
      电话: <?php echo $row['tel_num'];?>
      <br>
      E-mail: <?php echo $row['email'];?>
      <br>
      专长: <?php echo $row['specialty'];?>
      <br>
    </fieldset>

<?php
   }
} else{
   $department_sql = "SELECT department FROM departments";
   try{
      $result = mysqli_query($conn, $department_sql);
      if (mysqli_num_rows($result) <= 0)
         header("Location: http://127.0.0.1/patient_page/patient_page.php?status=1");
   }
   catch(Exception $e){
      echo '// WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/patient_page/patient_page.php?status=1");
   }
?>
   <label for="department">科室</label>
   <form action="" method="post">
   <select name="department" >
   <option value="">--- 选择科室 ---</option>
<?php
   while($row = mysqli_fetch_array($result))
      echo "<option value=".$row['department'].">".$row['department']."</option>";
?>
   </select>
   <input type="hidden" name="id" value="<?=$id?>">
   <input type="submit" value="提交">
   </form>
<?php
}
?>

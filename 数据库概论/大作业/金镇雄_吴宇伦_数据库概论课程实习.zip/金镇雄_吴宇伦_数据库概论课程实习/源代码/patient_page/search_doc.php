<?php
$id='';
if(!empty($_POST['id']))
   $id=$_POST['id'];
$conn = mysqli_connect("localhost","patient","patient","hospitaldb");
if(mysqli_connect_errno()){
   echo mysqli_correct_error();
}
$department = !empty($_POST['department'])?$_POST['department']:'';
if($department){
   $doctor_sql = "SELECT * FROM doctor WHERE department = '{$department}'";
   try{
      $result = mysqli_query($conn, $doctor_sql);
      if (mysqli_num_rows($result) <= 0){
         mysqli_close($result);
         header("Location: http://127.0.0.1/patient_page/patient_page.php?id={$id}&status=1");
      }
   }
   catch(Exception $e){
      echo '// WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/patient_page/patient_page.php?id={$id}&status=1");
   }
   while($row = mysqli_fetch_array($result)){
?>
      <form method="post" action="questionnaire.php">
      名字: <?php echo $row['name'];?>
      <br>
      职称: <?php echo $row['title'];?>
      <br>
      电话: <?php echo $row['tel_num'];?>
      <br>
      E-mail: <?php echo $row['email'];?>
      <br>
      专长: <?php echo $row['specialty'];?>
      <br>
      <input type="hidden" name="pid" value="<?php echo $id;?>">
      <input type="hidden" name="did" value="<?php echo $row['doctor_id'];?>">
      <input type="submit" name="submit" value="预约">
      </form>
<?php
   }
   mysqli_close($conn);
} else{
   $department_sql = "SELECT department FROM departments";
   try{
      $result = mysqli_query($conn, $department_sql);
      if (mysqli_num_rows($result) <= 0)
         header("Location: http://127.0.0.1/patient_page/patient_page.php?id={$id}&status=1");
   }
   catch(Exception $e){
      echo '// WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
      header("Location: http://127.0.0.1/patient_page/patient_page.php?id={$id}&status=1");
   }
?>
   <label for="department">科室</label>
   <form action="" method="post">
   <select name="department" id="department">
   <option value="">--- 选择科室 ---</option>
<?php
   while($row = mysqli_fetch_array($result))
      echo "<option value=".$row['department'].">".$row['department']."</option>";
   mysqli_close($conn);
?>
   </select>
   <input type="hidden" name="id" value="<?php echo $id;?>">
   <input type="submit" value="提交">
   </form>
<?php
}
?>

<?php
$pid = $_POST['pid'];
$did = $_POST['did'];
$flag = $_POST['flag'];
$datetime = $_POST['app_datetime'];
$make_app_sql = "INSERT INTO appointment(doctor_id, patient_id, time, referral) VALUE('{$did}', '{$pid}', '{$datetime}', '{$flag}')";
$conn = mysqli_connect("localhost","patient","patient","hospitaldb");
try{
    if(mysqli_query($conn, $make_app_sql)){
      	echo "<h1> 预约成功！</h1>";
		echo "<form action=\"/../patient_page/patient_page.php?id={$pid}\" method=\"post\">
        	<input type=\"submit\" value=\"返回\">
      		</form>";
    }
}
catch(Exception $e){
    mysqli_rollback($conn);
    echo "预约失败";
    error_log(mysqli_error($conn));
    header("Location: http://127.0.0.1/patient_page/patient_page.php?id={$pid}&status=1");
}
?>
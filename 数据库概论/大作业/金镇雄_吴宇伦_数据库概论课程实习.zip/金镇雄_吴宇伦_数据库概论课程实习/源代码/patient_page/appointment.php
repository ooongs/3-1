<html>
<head>
<meta charset="utf-8">
<title>预约</title>
</head>
<body>
<?php
$pid = $_POST['pid'];
$did = $_POST['did'];
$flag = $_POST['flag'];
$msg1 = $msg2 = "";
$date = empty($_POST['app_date'])?null:$_POST['app_date'];
$time = empty($_POST['app_time'])?null:$_POST['app_time'];
?>
<script type="text/javascript">
	function mysubmit(x){
		document.getElementById(x).submit();
	}
</script>
预约日期:
<form id="date_select" method="post" action="" onchange="mysubmit(this.id)">
   <input type="date" id="app_date" name="app_date" value="<?php echo $date;?>" min="<?php echo date('Y-m-d', strtotime("tomorrow"));?>" max="<?php echo date('Y-m-d', strtotime("+1 week"));?>" required>
   <?php echo $msg1;?>
   <input type="hidden" name="pid" value="<?php echo $pid;?>">
   <input type="hidden" name="did" value="<?php echo $did;?>">
   <input type="hidden" name="flag" value="<?php echo $flag;?>">
</form>
<?php
if(!empty($_POST['app_date'])){
	$date = $_POST['app_date'];
	$conn = mysqli_connect("localhost","patient","patient","hospitaldb");
   if(mysqli_connect_errno())
      echo mysqli_correct_error();
	$search_app_sql1 = "SELECT COUNT(1) FROM appointment WHERE doctor_id = {$did} and DATE(time) = '{$date}'";
	$result1 = mysqli_query($conn, $search_app_sql1);
   $num1 = mysqli_fetch_array($result1)[0];
	if($num1 >= 30){
      $msg1 = "当日预约已满, 请重新选择日期<br>";
   } else{
      $msg1 = "";
?>
预约时间:
<form id="time_select" method="post" action="" onchange="mysubmit(this.id)">
   <input type="time" id="app_time" name="app_time" list="avai_time" value="<?php echo $time;?>" required>
   <?php echo $msg2;?>
   <datalist id="avai_time">
      <option value="9:00">
    	<option value="9:30">
    	<option value="10:00">
    	<option value="10:30">
    	<option value="11:00">
		<option value="11:30">
    	<option value="13:00">
    	<option value="13:30">
    	<option value="14:00">
    	<option value="14:30">
		<option value="15:00">
    	<option value="15:30">
   </datalist>
   <input type="hidden" name="pid" value="<?php echo $pid;?>">
   <input type="hidden" name="did" value="<?php echo $did;?>">
   <input type="hidden" name="flag" value="<?php echo $flag;?>">
   <input type="hidden" name="app_date" value="<?php echo $date;?>">
   <br><br>
   <small>工作时间为9:00-12:00和13:00-16:00</small>
   <br><br>
</form>
<?php
      if(!empty($_POST['app_time'])){
         $datetime = $date." ".$time.":00";
         $search_app_sql2 = "SELECT COUNT(1) FROM appointment WHERE doctor_id = {$did} and time = '{$datetime}'";
         $result2 = mysqli_query($conn, $search_app_sql2);
         $num2 = mysqli_fetch_array($result2)[0];
         $msg2 = "该时段已预约人数: ".$num2;

         echo "<form method=\"post\" action=\"app_result.php\">";
         echo "<input type=\"hidden\" name=\"pid\" value=".$pid.">";
         echo "<input type=\"hidden\" name=\"did\" value=".$did.">";
         echo "<input type=\"hidden\" name=\"flag\" value=".$flag.">";
         echo "<input type=\"hidden\" name=\"app_datetime\" value=".$datetime.">";
         echo "<input type=\"submit\" name=\"submit\" value=\"提交\">";
         echo "</form>";
      }
   }
}
?>
</body>
</html>

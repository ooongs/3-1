<html>
<head>
<meta charset="utf-8">
<title>预约流调表</title>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>

<?php
$pid = $_POST['pid'];
$did = $_POST['did'];
$track = $respiratory = $fever = "";
$flag = 2;

if(!empty($_POST['track'])){
   $track = $_POST['track'];
   if($track == "y")
      $flag = 1;
   else
      $flag = 0;
}

if(empty($_POST['fever'])){
   $flag = 2;
} else{
   $fever = $_POST['fever'];
   if($fever == "y")
      $flag = 1;
}
if(empty($_POST['respiratory'])){
   $flag = 2;
} else{
   $respiratory = $_POST['respiratory'];
   if($respiratory == "y")
      $flag = 1;
}

?>
<h2>预约流调表</h2>
<form method="post" action="">
   14天内是否经过中高风险地区:
   <input type="radio" name="track" <?php if (isset($track) && $track=="y") echo "checked";?> value="y">是
   <input type="radio" name="track" <?php if (isset($track) && $track=="n") echo "checked";?> value="n">否
   <span class="error">* <?php if($track != "y" && $track != "n") echo "必填";?></span>
   <br><br>
   是否有发热、乏力等症状:
   <input type="radio" name="fever" <?php if (isset($fever) && $fever=="y") echo "checked";?> value="y">是
   <input type="radio" name="fever" <?php if (isset($fever) && $fever=="n") echo "checked";?> value="n">否
   <span class="error">* <?php if($fever != "y" && $fever != "n") echo "必填";?></span>
   <br><br>
   是否有呼吸道症状:
   <input type="radio" name="respiratory" <?php if (isset($respiratory) && $respiratory=="y") echo "checked";?> value="y">是
   <input type="radio" name="respiratory" <?php if (isset($respiratory) && $respiratory=="n") echo "checked";?> value="n">否
   <span class="error">* <?php if($respiratory != "y" && $respiratory != "n") echo "必填";?></span>
   <br><br>
   <input type="hidden" name="pid" value="<?php echo $pid;?>">
   <input type="hidden" name="did" value="<?php echo $did;?>">
   <input type="submit" name="submit" value="确认">
</form>
<?php
   if($flag != 2){
      echo "<form method=\"post\" action=\"appointment.php\">";
      echo "<input type=\"hidden\" name=\"flag\" value=".$flag.">";
      echo "<input type=\"hidden\" name=\"pid\" value=".$pid.">";
      echo "<input type=\"hidden\" name=\"did\" value=".$did.">";
      echo "<input type=\"submit\" name=\"submit\" value=\"进行预约\">";
      echo "</form>";
   }
?>
</body>
</html>

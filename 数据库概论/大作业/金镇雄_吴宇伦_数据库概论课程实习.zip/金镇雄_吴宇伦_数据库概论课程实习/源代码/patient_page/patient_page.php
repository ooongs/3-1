<?php

$conn = mysqli_connect("localhost","patient","patient","hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$id='';
$user='';
if(isset($_GET['user']))$user = $_GET['user'];
if(isset($_GET['id']))$id = $_GET['id'];
if(!empty($_POST['id'])) $id = $_POST['id'];
$info_sql = "SELECT * FROM patient WHERE username= '{$user}' OR patient_id='{$id}'";
$result = mysqli_query($conn, $info_sql);
if($result === false){
    echo '// WARNING: WRONG DATA';
    error_log(mysqli_error($conn));
}
else {
  if($row = mysqli_fetch_array($result)){
    echo "
      <form action=\"/../hospital.php\" method=\"post\">
        <input type=\"submit\" name=\"id\" value=\"退出登录\" placeholder=\"rrepd\">
      </form>";
    echo "<h1> 患者个人信息 </h1>";
    echo "<table><thead><tr><th colspan=\"2\"></th></tr></thead><tbody>";
    echo "<tr><td>姓名</td><td>".$row['name']."</td></tr>";
    echo "<tr><td>登录名</td><td>".$row['username']."</td></tr>";
    echo "<tr><td>性别</td><td>".$row['sex']."</td></tr>";
    echo "<tr><td>出生年月日</td><td>".$row['birthdate']."</td></tr>";
    echo "<tr><td>电话</td><td>
          <form action=\"/../info_update.php\"method=\"post\">
            <input type='hidden' name='user' value=$user>
            <input type='hidden' name='type' value='patient'>
            <input type=\"text\" name=\"tel_num\" placeholder=\"".$row['tel_num']."\" minlength=\"11\" maxlength=\"11\" required>
            <input type=\"submit\" value=\"修改\">
            </form></td></tr>";
    echo "<tr><td>电子邮件</td><td>
          <form action=\"/../info_update.php\"method=\"post\">
            <input type='hidden' name='user' value=$user>
            <input type='hidden' name='type' value='patient'>
            <input type=\"email\" name=\"email\" placeholder=\"".$row['email']."\" maxlength=\"256\" required>
            <input type=\"submit\" value=\"修改\">
          </form></td></tr>";

    echo "<tr><td>密码</td><td>
          <form action=\"/../info_update.php\"method=\"post\">
            <input type='hidden' name='user' value=$user>
            <input type='hidden' name='type' value='patient'>
            <input type=\"text\" name=\"password\" placeholder=\"".$row['password']."\" maxlength=\"15\" required>
            <input type=\"submit\" value=\"修改\">
          </form></td></tr>";
    echo "</tbody></table>";
    if(isset($_GET['status']) && $_GET['status']=='1') echo '<h3>FAILED TO UPDATE</h3>';
    echo "
          <form action=\"search_doc.php\" method=\"post\">
            <input type=\"hidden\" name=\"id\" value=".$row['patient_id'].">
            <input type=\"submit\"  value=\"查看医生\">
          </form>";
    echo "
          <form action=\"search_dept.php\" method=\"post\">
            <input type=\"hidden\" name=\"id\" value=".$row['patient_id'].">
            <input type=\"submit\"  value=\"查看科室\">
          </form>";
    echo "
          <form action=\"record.php\" method=\"post\">
            <input type=\"hidden\" name=\"id\" value=".$row['patient_id'].">
            <input type=\"submit\" value=\"查看病历\">
          </form>";
    echo "
          <form action=\"app_record.php\" method=\"post\">
            <input type=\"hidden\" name=\"id\" value=".$row['patient_id'].">
            <input type=\"submit\" value=\"查看预约记录\">
          </form>";
  }
}

?>

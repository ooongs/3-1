<?php
$chief_id = $_POST['chief_id'];
$docs = array();
echo "<form action=\"/../doctor_page/doctor_page.php\" method=\"post\">
        <input type='hidden' name='doctor_id' value='{$chief_id}'>
        <input type=\"submit\" value=\"返回\">
      </form>";
$conn = mysqli_connect('localhost','chief','chief','hospitaldb');
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}

$doc_sql = "SELECT doctor_id FROM chief_doc_view WHERE chief_id = '{$chief_id}'";

$doc_result = mysqli_query($conn, $doc_sql);
if($doc_result){
    while($row = mysqli_fetch_array($doc_result)){
      array_push($docs, $row['doctor_id']);
    }
}
?>

<h3>下属医生</h3>

<form action='search_mr_page.php?type=2' method='post'>
  <fieldset>
    <legend>SELECT DOCTOR</legend>
    <label for="Docs">医生ID</label>
        <select name="doctor_id">
           <option value="">--- 选择ID ---</option>
           <?php
              for ($i=0; $i < count($docs); $i++) {
                echo "<option value=".$docs[$i].">".$docs[$i]."</option>";
              }
           ?>
        </select>
    <input type="hidden" name="chief_id" value="<?=$chief_id?>">
    <input type='submit' value='提交'>
  </fieldset>
</form>

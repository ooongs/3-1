<?php
$patient_id = '';
$patient_name = '';
$doctor_id = '';
$doctor_name = '';
$chief_id = '';
$mr_search = '';
if(!empty($_POST['patient_id'])) $patient_id = $_POST['patient_id'];
if(!empty($_POST['patient_name'])) $patient_name = $_POST['patient_name'];
if(!empty($_POST['doctor_id'])) $doctor_id = $_POST['doctor_id'];
if(!empty($_POST['doctor_name'])) $doctor_name = $_POST['doctor_name'];
if(!empty($_POST['chief_id'])) $chief_id = $_POST['chief_id'];

if(isset($_GET['type']) && $_GET['type'] == 0){
  echo "<form action=\"/../doctor_page/create_mr_page.php\" method=\"post\">
          <input type='hidden' name='doctor_id' value='{$doctor_id}'>
          <input type='hidden' name='patient_id' value='{$patient_id}'>
          <input type='hidden' name='doctor_name' value='{$doctor_name}'>
          <input type='hidden' name='patient_name' value='{$patient_name}'>
                  <div><input type='hidden' name='time' value='{$_POST['time']}'></div>
          <input type=\"submit\" value=\"返回\">
        </form>";
        $mr_search = "
            SELECT diagnosed_time, complaints, treatment, allergy, diagnosis, paroxysm_time,
                    present_history, past_history, doctor_name, patient_name, medicine_name, medicine_num
            FROM medical_record NATURAL JOIN recipes
            WHERE patient_id = '{$patient_id}'
            ORDER BY diagnosed_time
        ";
}
else if(isset($_GET['type']) && $_GET['type'] == 1){
  echo "<form action=\"/../doctor_page/doctor_page.php\" method=\"post\">
          <input type='hidden' name='doctor_id' value='{$doctor_id}'>
          <input type=\"submit\" value=\"返回\">
        </form>";
        $mr_search = "
            SELECT diagnosed_time, complaints, treatment, allergy, diagnosis, paroxysm_time,
                    present_history, past_history, doctor_name, patient_name, medicine_name, medicine_num
            FROM medical_record NATURAL JOIN recipes
            WHERE doctor_id = '{$doctor_id}'
            ORDER BY diagnosed_time
        ";
}
else{
  echo "<form action=\"/../doctor_page/chief_search_doc_mr.php\" method=\"post\">
          <input type='hidden' name='chief_id' value='{$chief_id}'>
          <input type=\"submit\" value=\"返回\">
        </form>";
        $mr_search = "
            SELECT diagnosed_time, complaints, treatment, allergy, diagnosis, paroxysm_time,
                    present_history, past_history, doctor_name, patient_name, medicine_name, medicine_num
            FROM medical_record NATURAL JOIN recipes
            WHERE doctor_id = '{$doctor_id}'
            ORDER BY diagnosed_time
        ";
}
$conn = mysqli_connect("localhost","doctor","doctor","hospitaldb");
if(mysqli_connect_errno()){
    echo mysqli_correct_error();
}

$result = mysqli_query($conn,$mr_search);
$flag=0;
?>
<fieldset>
    <legend><b><?php if($_GET['type'] == 0) echo "姓名: ".$patient_name; else echo "DOCTOR ID: ".$doctor_id;?></b><br></legend>
    <?php
    while($row = mysqli_fetch_array($result)){
      $flag=1;
    ?>
      <fieldset>
        <legend><b><?=$row['diagnosed_time']?></b></legend>
        <b>诊断患者: </b><?=$row['patient_name']?><br>
        <b>诊断医生: </b><?=$row['doctor_name']?><br>
        <b>发病时间: </b><?=$row['paroxysm_time']?><br>
        <b>主诉: </b><?=$row['complaints']?><br>
        <b>现病史: </b><?=$row['present_history']?><br>
        <b>现病治疗情况: </b><?=$row['treatment']?><br>
        <b>既往史: </b><?=$row['past_history']?><br>
        <b>过敏史: </b><?=$row['allergy']?><br>
        <b>评估诊断: </b><?=$row['diagnosis']?>
        <fieldset>
          <legend><b>处方</b></legend>
          <b>药名: </b><?=$row['medicine_name']?><br>
          <b>数量: </b><?=$row['medicine_num']?><br>
        </fieldset>
      </fieldset>
</fieldset>
<?php
}
if($flag == 0){
  echo "NO MEDICAL RECORD FOUND";
}

?>

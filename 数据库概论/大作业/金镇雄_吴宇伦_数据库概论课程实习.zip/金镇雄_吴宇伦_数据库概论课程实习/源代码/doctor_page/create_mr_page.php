<?php
$patient_id = $_POST['patient_id'];
$patient_name = $_POST['patient_name'];
$doctor_id = $_POST['doctor_id'];
$doctor_name = $_POST['doctor_name'];

echo "<form action=\"/../doctor_page/search_appointment.php\" method=\"post\">
        <input type='hidden' name='doctor_id' value='{$doctor_id}'>
        <input type=\"submit\" value=\"返回\">
      </form>";
echo "<form action='/../doctor_page/search_mr_page.php?type=0' method='post'>
        <input type='hidden' name='doctor_id' value='{$doctor_id}'>
        <input type='hidden' name='patient_id' value='{$patient_id}'>
        <input type='hidden' name='doctor_name' value='{$doctor_name}'>
        <input type='hidden' name='patient_name' value='{$patient_name}'>
        <input type='hidden' name='time' value='{$_POST['time']}'>
        <input type='submit' value='查看历史病例'>
      </form>";
$conn = mysqli_connect("localhost","doctor","doctor","hospitaldb");
if(mysqli_connect_errno()){
    echo mysqli_correct_error();
}
$medicine_search= "
  SELECT * FROM medicine
";
$medicine_arr = array();
$result = mysqli_query($conn,$medicine_search);
?>
<form action='create_medical_record.php' method='post'>
      <fieldset>
        <legend>病历表 <?=$_POST['time']?></legend>
        ID: <?=$patient_id?><br>
        姓名: <?=$patient_name?><br>
        <div>
          <label for='paroxysm_time'>发病时间: </label>
          <input type='text' name='paroxysm_time' value='' maxlength='32' required>
        </div>
        <div>
          <label for='complaints'>主诉: </label>
          <p><textarea name="complaints" rows="10" cols="80" maxlength="1024" required></textarea> </p>
        </div>
        <div>
          <label for='present_history'>现病史: </label>
          <p><textarea name="present_history" rows="10" cols="80" maxlength="1024" required></textarea> </p>
        </div>
        <div>
          <label for='treatment'>现病治疗情况: </label>
          <p><textarea name="treatment" rows="10" cols="80" maxlength="1024" required></textarea> </p>
        </div>
        <div>
          <label for='past_history'>既往史: </label>
          <p><textarea name="past_history" rows="10" cols="80" maxlength="1024" required></textarea> </p>
        </div>
        <div>
          <label for='allergy'>过敏史: </label>
          <p><textarea name="allergy" rows="10" cols="80" maxlength="1024" required></textarea> </p>
        </div>
        <div>
          <label for='diagnosis'>评估诊断: </label>
          <p><textarea name="diagnosis" rows="10" cols="80" maxlength="1024" required></textarea> </p>
        </div>
        <fieldset>
          <legend>处方表</legend>
          <label for="Unselected_Doc">药名</label>
              <select name="medicine_name">
                 <option value="">--- Select Medicine ---</option>
                 <?php
                  while($row = mysqli_fetch_array($result)) {
                      echo "<option value=".$row['medicine_name'].">".$row['medicine_name']."</option>";
                    }
                 ?>
              </select>
          <input type='text' name='medicine_num' placeholder="数量">
        </fieldset>
        <br>
        <div><input type='hidden' name='patient_id' value='<?=$patient_id?>'></div>
        <div><input type='hidden' name='patient_name' value='<?=$patient_name?>'></div>
        <div><input type='hidden' name='doctor_id' value='<?=$doctor_id?>'></div>
        <div><input type='hidden' name='doctor_name' value='<?=$doctor_name?>'></div>
        <div><input type='hidden' name='diagnosed_time' value='<?=$_POST['time']?>'></div>
        <div><input type='submit' value='确认'></div>
      </fieldset>
</form>

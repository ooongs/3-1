<?php
$id='';
$user='';
if(isset($_GET['id'])){
  $id=$_GET['id'];
}
if(isset($_GET['user'])){
  $user = $_GET['user'];
}
if(!empty($_POST['id'])){
  $id=$_POST['id'];
}
if(!empty($_POST['doctor_id'])){
  $id=$_POST['doctor_id'];
}
$alert = 0;
$conn = mysqli_connect("localhost","doctor","doctor","hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$info_sql = "SELECT * FROM doctor WHERE username='$user' OR doctor_id='$id'";

try{
  $info_result = mysqli_query($conn, $info_sql);
  if($info_result === false){
      echo '// WARNING: WRONG DATA';
      error_log(mysqli_error($conn));
  }
  else if($row = mysqli_fetch_array($info_result)){
      $chief_name = '';
      $chief_telnum = '';
      if($row['is_chief'] == '0'){
        $dept_sql = "SELECT name, tel_num
                         FROM doctor c JOIN departments d
                         ON c.doctor_id = d.chief_id
                         WHERE d.department = '{$row['department']}'
                         ";
                         // chief name and tel_num;

        $dept_result = mysqli_query($conn, $dept_sql);
        if($dept_row = mysqli_fetch_array($dept_result)){
            $chief_name = $dept_row['name'];
            $chief_telnum = $dept_row['tel_num'];
        }
        $alert_sql = "SELECT * FROM alert_table WHERE doctor_id = '{$row['doctor_id']}' AND time > NOW()";
        $r = mysqli_query($conn, $alert_sql);
        if(mysqli_fetch_array($r)){
          $alert = 1;
        }
      }
      else{
          $alert_sql = "SELECT * FROM dept_doc_alert WHERE chief_id = '{$row['doctor_id']}'";
          $r = mysqli_query($conn, $alert_sql);
          if(mysqli_fetch_array($r))
            $alert = 2;
      }
      echo "
        <form action=\"/../hospital.php\" method=\"post\">
          <input type=\"submit\" name=\"id\" value=\"退出登录\" placeholder=\"rrepd\">
        </form>";
      if($row['is_chief'] == '0'){
        echo "<h1> 医生个人信息 </h1>";
      } else echo "<h1> 科长个人信息 </h1>";
      echo "<table><thead><tr><th colspan=\"2\"></th></tr></thead><tbody>";
      echo "<tr><td>姓名</td><td>".$row['name']."</td></tr>";
      echo "<tr><td>登录名</td><td>".$row['username']."</td></tr>";
      echo "<tr><td>性别</td><td>".$row['sex']."</td></tr>";
      echo "<tr><td>出生年月日</td><td>".$row['birthdate']."</td></tr>";
      echo "<tr><td>毕业院校</td><td>".$row['graduate']."</td></tr>";
      echo "<tr><td>学位</td><td>".$row['degree']."</td></tr>";
      echo "<tr><td>技术职称</td><td>".$row['title']."</td></tr>";
      echo "<tr><td>技术特长</td><td>".$row['specialty']."</td></tr>";
      echo "<tr><td>科室</td><td>".$row['department']."</td></tr>";
      if($row['is_chief'] == '0'){
        echo "<tr><td>科长</td><td>".$chief_name."</td></tr>";
        echo "<tr><td>科长电话</td><td>".$chief_telnum."</td></tr>";
      }
      echo "<br>";
      echo "<tr><td>电话</td><td>
            <form action=\"/../info_update.php\"method=\"post\">
              <input type='hidden' name='user' value=$user>
              <input type='hidden' name='type' value='doctor'>
              <input type=\"text\" name=\"tel_num\" placeholder=\"".$row['tel_num']."\" minlength=\"11\" maxlength=\"11\" required>
              <input type=\"submit\" value=\"修改\">
              </form></td></tr>";
      echo "<tr><td>电子邮件</td><td>
            <form action=\"/../info_update.php\"method=\"post\">
              <input type='hidden' name='user' value=$user>
              <input type='hidden' name='type' value='doctor'>
              <input type=\"email\" name=\"email\" placeholder=\"".$row['email']."\" maxlength=\"256\" required>
              <input type=\"submit\" value=\"修改\">
            </form></td></tr>";
      echo "<tr><td>密码</td><td>
            <form action=\"/../info_update.php\"method=\"post\">
              <input type='hidden' name='user' value=$user>
              <input type='hidden' name='type' value='doctor'>
              <input type=\"text\" name=\"password\" placeholder=\"".$row['password']."\" maxlength=\"15\" required>
              <input type=\"submit\" value=\"修改\">
            </form></td></tr>";
      echo "</tbody></table>";
      if(isset($_GET['status']) && $_GET['status']=='1') echo '<h3>FAILED TO UPDATE</h3>';
      echo "
      <form action=\"search_appointment.php\" method=\"post\">
        <input type=\"hidden\" name=\"doctor_id\" value=\"".$row['doctor_id']."\">
        <input type=\"submit\" name=\"update\" value=\"查看预约\">
      </form>";
      echo "
      <form action=\"search_mr_page.php?type=1\" method=\"post\">
        <input type=\"hidden\" name=\"doctor_id\" value=\"".$row['doctor_id']."\">
        <input type=\"submit\" name=\"update\" value=\"查看病历与处方\">
      </form>";
      if($row['is_chief'] == '1'){
        echo "
        <form action=\"../department/department_update_page.php?dept={$row['department']}\" method=\"post\">
          <input type=\"hidden\" name=\"dept\" value=\"".$row['department']."\">
          <input type=\"submit\" name=\"update\" value=\"管理科室\">
        </form>";
        echo "
        <form action=\"chief_search_doc_mr.php\" method=\"post\">
          <input type=\"hidden\" name=\"chief_id\" value=\"".$row['doctor_id']."\">
          <input type=\"submit\" name=\"update\" value=\"查看下属医生病历与处方\">
        </form>";
      }
      if($row['department'] == 'Fever'){
        echo "
        <form action=\"fever_appointment_check.php?dept={$row['department']}\" method=\"post\">
          <input type=\"hidden\" name=\"doctor_id\" value=\"".$row['doctor_id']."\">
          <input type=\"submit\" name=\"update\" value=\"发热门诊\">
        </form>";
      }
      if($alert == 2){
        echo "<b>风险等级为高，接诊医生和科长需注意</b>";
      }else if($alert == 1){
        echo "<b>风险等级为高，接诊医生需注意</b>";
      }
    }
}
catch(Exception $e){
  header("http://127.0.0.1/hospital.php");
}


?>

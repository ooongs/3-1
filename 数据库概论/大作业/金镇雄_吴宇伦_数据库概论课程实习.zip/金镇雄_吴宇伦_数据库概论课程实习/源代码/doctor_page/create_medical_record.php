<?php
$conn = mysqli_connect("localhost","doctor","doctor","hospitaldb");
if(mysqli_connect_errno()){
    echo mysqli_correct_error();
}
$insert_mr= "
      INSERT INTO medical_record(patient_name,doctor_name,diagnosed_time,complaints,treatment,
                  allergy,diagnosis,paroxysm_time,present_history,past_history,doctor_id,patient_id)
      VALUES ('{$_POST['patient_name']}','{$_POST['doctor_name']}','{$_POST['diagnosed_time']}','{$_POST['complaints']}',
      '{$_POST['treatment']}','{$_POST['allergy']}','{$_POST['diagnosis']}','{$_POST['paroxysm_time']}',
      '{$_POST['present_history']}','{$_POST['past_history']}',{$_POST['doctor_id']},{$_POST['patient_id']})
";
$insert_recipe = "
    INSERT INTO recipes(record_id,medicine_name,medicine_num)
    VALUES(LAST_INSERT_ID(),'{$_POST['medicine_name']}',{$_POST['medicine_num']})
";

  mysqli_begin_transaction($conn, MYSQLI_TRANS_START_READ_WRITE);
  mysqli_query($conn,$insert_mr);
  mysqli_query($conn,$insert_recipe);
  mysqli_commit($conn);
  echo $insert_mr."<br>";
  echo $insert_recipe;
  echo "<h1>创建病历表成功</h1>";
  echo "<form action=\"/../doctor_page/search_appointment.php\" method=\"post\">
          <input type='hidden' name='doctor_id' value='{$_POST['doctor_id']}'>
          <input type=\"submit\" value=\"返回\">
        </form>";
        try{
}catch(Exception $e){
  echo ' WARNING: WRONG DATA';
  error_log(mysqli_error($conn));
  header("Location: http://127.0.0.1/doctor_page/doctor_page.php?id={$_POST['doctor_id']}&status=1");
}
?>

<?php
$patient_id = $_POST['patient_id'];
$doctor_id = $_POST['doctor_id'];
$id = $_POST['id'];
$time = $_POST['time'];
$conn = mysqli_connect("localhost",'doctor','doctor',"hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$appointment_update = "
    UPDATE appointment
    SET referral = 0
    WHERE patient_id = '{$patient_id}' AND doctor_id = '{$doctor_id}' AND time = '{$time}'
";
echo $appointment_update.'<br>';
mysqli_query($conn, $appointment_update);
echo "<h1> 修改成功 ！</h1>";
echo
    "<form action=\"fever_appointment_check.php\" method=\"post\">
      <input type='hidden' name='doctor_id' value='".$id."'>
      <input type=\"submit\" value=\"返回\">
    </form>";
?>

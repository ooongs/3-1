<?php
$id='';
if(!empty($_POST['doctor_id'])) $id=$_POST['doctor_id'];
echo "<form action=\"/../doctor_page/doctor_page.php?id={$id}\" method=\"post\">
        <input type=\"submit\" value=\"返回\">
      </form>";
$conn = mysqli_connect("localhost","doctor","doctor","hospitaldb");
if(mysqli_connect_errno()){
  echo mysqli_correct_error();
}
$appointment_sql = "SELECT * FROM appointment_view WHERE doctor_id = '{$id}' AND time >= NOW() AND referral = 0 AND finish = 0 ORDER BY time ASC";
$result = mysqli_query($conn, $appointment_sql);
$check = 1;
while($row = mysqli_fetch_array($result)){
  if($check == 1) {
    echo"<h1>APPOINTMENT OF ".$row['doctor_name']."</h1>";
    $check = 0;
  }
  ?>
  <fieldset>
    <legend><?=$row['patient_name']?></legend>
    科室: <?=$row['department']?><br>
    电话: <?=$row['patient_tel']?><br>
    体温: <?=$row['temperature']?><br>
    时间: <?=$row['time']?><br><br>
    <form class="" action="create_mr_page.php" method="post">
      <input type="hidden" name="doctor_id" value='<?=$row['doctor_id']?>'>
      <input type="hidden" name="patient_id" value='<?=$row['patient_id']?>'>
      <input type="hidden" name="doctor_name" value='<?=$row['doctor_name']?>'>
      <input type="hidden" name="patient_name" value='<?=$row['patient_name']?>'>
      <input type="hidden" name="time" value='<?=$row['time']?>'>
      <input type="submit" name="" value="确认">
    </form>
  </fieldset>
  <?php
}
if($check == 1){
  echo "<h1>NO APPOINTMENT FOUND</h1>";
}
?>

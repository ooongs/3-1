/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     12/19/2021 5:15:30 PM                        */
/*==============================================================*/

use hospitaldb;
drop view if exists appointment_view;
drop view if exists department_view;
drop table if exists recipes;
drop table if exists medicine;
drop table if exists alert_table;
drop table if exists appointment;
drop table if exists medical_record;
drop table if exists patient;
drop table if exists doctor;
drop table if exists login;
drop table if exists departments;
drop user if exists 'doctor'@'localhost';
drop user if exists 'patient'@'localhost';
drop user if exists 'dba'@'localhost';
drop user if exists 'chief'@'localhost';
flush privileges;

create user 'dba'@'localhost' identified by 'dba';
create user 'chief'@'localhost' identified by 'chief';
create user 'doctor'@'localhost' identified by 'doctor';
create user 'patient'@'localhost' identified by 'patient';
/*==============================================================*/
/* Table: departments                                           */
/*==============================================================*/
create table departments
(
   chief_id             int(11),
   department           varchar(32) not null,
   description          varchar(1024) not null,
   primary key (department)
);

/*==============================================================*/
/* Table: people                                                */
/*==============================================================*/
create table login
(
  username 				varchar(15) not null unique,
  password 				varchar(20) not null,
  type 					enum('DOCTOR','PATIENT','DBA') not null,
  primary key (username)
);

/*==============================================================*/
/* Table: patient                                               */
/*==============================================================*/
create table patient
(
   name					varchar(50) not null,
   birthdate			date not null,
   sex 					enum('MALE','FEMALE') not null,
   tel_num				char(11) not null,
   email				varchar(256) default null,
   username				varchar(15) not null,
   password				varchar(20) not null,
   id_card_num          varchar(18) not null unique,
   patient_id           int(11) not null auto_increment,
   primary key (patient_id)
);

/*==============================================================*/
/* Table: doctor                                                */
/*==============================================================*/
create table doctor
(
   name					varchar(50) not null,
   birthdate			date not null,
   sex 					enum('MALE','FEMALE') not null,
   tel_num				char(11) not null,
   email				varchar(256) default null,
   username				varchar(15) not null unique,
   password				varchar(20) not null,
   is_chief				bool not null,
   id_card_num          varchar(18) not null unique,
   doctor_id        	int(11) not null auto_increment,
   department           varchar(32) not null,
   graduate             varchar(32) not null,
   degree               enum('Post', 'Doctor', 'Master', 'Bachelor', 'Junior') not null,
   title                varchar(32) not null,
   specialty            varchar(256) not null,
   primary key (doctor_id),
   foreign key (department)
      references departments (department) on delete restrict on update restrict
);

/*==============================================================*/
/* Table: appointment                                           */
/*==============================================================*/
create table appointment
(
   appointment_id		int(11) not null auto_increment,
   doctor_id            int(11) not null,
   patient_id           int(11) not null,
   time                 datetime not null,
   referral				bool not null,
   finish				bool default false,
   temperature			numeric(3, 1) default 37.0,
   primary key (appointment_id),
   foreign key (patient_id)
      references patient (patient_id) on delete restrict on update restrict,
   foreign key (doctor_id)
      references doctor (doctor_id) on delete restrict on update restrict
);

/*==============================================================*/
/* Table: medical_record                                        */
/*==============================================================*/
create table medical_record
(
   record_id 			int(11) not null auto_increment,
   patient_name         varchar(32) not null,
   doctor_name          varchar(32) not null,
   diagnosed_time       datetime not null,
   complaints           varchar(1024) not null,
   treatment            varchar(1024) default null,
   allergy              varchar(1024) default null,
   diagnosis            varchar(1024) not null,
   paroxysm_time        varchar(32) not null,
   present_history      varchar(1024) default null,
   past_history         varchar(1024) default null,
   doctor_id            int(11) not null,
   patient_id           int(11) not null,
   paid					bool default false,
   primary key (record_id),
   foreign key (patient_id)
      references patient (patient_id) on delete restrict on update restrict,
   foreign key (doctor_id)
      references doctor (doctor_id) on delete restrict on update restrict
);

create table medicine
(
	medicine_name		varchar(64) primary key,
    medicine_id			varchar(4) unique,
    medicine_price		numeric(5,1) not null
);
create table recipes
(
	record_id			int(11) not null,
    medicine_name		varchar(64) not null,
    medicine_num		int,
    primary key (record_id, medicine_name),
    foreign key (record_id)
		references medical_record(record_id) on delete restrict on update restrict,
	foreign key (medicine_name)
		references medicine(medicine_name) on delete restrict on update restrict
);

create table alert_table
(
	patient_id			int(11) not null,
    doctor_id			int(11) not null,
    time				datetime not null,
    primary key (patient_id, doctor_id, time),
    foreign key (patient_id)
      references patient (patient_id) on delete restrict on update restrict,
    foreign key (doctor_id)
      references doctor (doctor_id) on delete restrict on update restrict
);

CREATE VIEW appointment_view AS 
	select d.name as doctor_name, p.name as patient_name, a.doctor_id as doctor_id, a.patient_id as patient_id, 
			d.tel_num as doctor_tel, p.tel_num as patient_tel, d.department as department, temperature, time, referral, finish
    from patient p, doctor d, appointment a    
	where p.patient_id = a.patient_id and d.doctor_id = a.doctor_id;
    
CREATE VIEW department_view AS 
	SELECT dept.chief_id as chief_id, d.name as chief_name, d.tel_num as chief_tel, dept.department as department, description
    FROM doctor as d, departments as dept
    WHERE d.doctor_id =  dept.chief_id; 

CREATE VIEW dept_doc_alert AS
	SELECT distinct(c.doctor_ID) as chief_id
    FROM doctor as d, doctor as c, alert_table as a
    WHERE d.department = c.department and c.is_chief = 1 and d.doctor_id = a.doctor_id and a.time > NOW();

CREATE VIEW chief_doc_view AS
	SELECT c.doctor_id as chief_id, d.doctor_id as doctor_id
    FROM doctor as d, doctor as c
    WHERE d.department = c.department and c.is_chief = 1;

delimiter $$
create trigger add_chief before insert on doctor for each row
begin
   declare chief_num int;
   if new.is_chief then
	  set chief_num = (select count(*) from doctor as D where D.department = new.department and D.is_chief);
      if chief_num > 0 then
         signal sqlstate 'CHIEF' set message_text = "Chief for the department exists.";
	  else
		 update departments
         set chief_id = new.doctor_id
	     where departments.department = new.department;
	  end if;
   end if;
end $$

delimiter $$
create trigger change_chief before update on doctor for each row
begin
   declare chief_num int;
   if old.is_chief = true and new.is_chief = false then
      update departments
      set chief_id = null
	  where departments.department = new.department;
   elseif new.is_chief = true and old.is_chief = false then 
	  set chief_num = (select count(*) from doctor as D where D.department = new.department and D.is_chief);
      if chief_num > 0 then
         signal sqlstate 'CHIEF' set message_text = "Chief for the department exists.";
	  else
		 update departments
         set chief_id = new.doctor_id
	     where departments.department = new.department;
	  end if;
   end if;
end $$

delimiter $$
create trigger finish_appointment after insert on medical_record for each row
begin
	update appointment
	set finish = true
	where appointment.doctor_id = new.doctor_id
		and appointment.patient_id = new.patient_id
        and date(appointment.time) = date(new.diagnosed_time);
end $$

delimiter $$
create trigger alert after insert on appointment for each row
begin
	if new.referral = true then 
	  insert into alert_table
      value(new.patient_id, new.doctor_id, new.time);
   end if;
end $$

grant update(email, password, tel_num, specialty) on doctor to 'doctor'@'localhost';
grant select, insert on medical_record to 'doctor'@'localhost';
grant select, delete, update on appointment to 'doctor'@'localhost';
grant insert, select(username), update(password) on login to 'doctor'@'localhost';
grant select on departments to 'doctor'@'localhost';
grant select, insert on doctor to 'doctor'@'localhost';
grant select on appointment_view to 'doctor'@'localhost';
grant select, insert on recipes to 'doctor'@'localhost';
grant select on medicine to 'doctor'@'localhost';
grant select on alert_table to 'doctor'@'localhost';
grant select on dept_doc_alert to 'doctor'@'localhost';
grant select on chief_doc_view to 'doctor'@'localhost';

grant insert, select, update(email,password,tel_num) on patient to 'patient'@'localhost';
grant select on doctor to 'patient'@'localhost';
grant select on medical_record to 'patient'@'localhost';
grant select on departments to 'patient'@'localhost';
grant insert, select, delete on appointment to 'patient'@'localhost';
grant insert,select(username), update(password) on login to 'patient'@'localhost';
grant select on appointment_view to 'patient'@'localhost';
grant select on medicine to 'patient'@'localhost';
grant select on recipes to 'patient'@'localhost';
grant select on dept_doc_alert to 'patient'@'localhost';
grant select on chief_doc_view to 'patient'@'localhost';

grant all on hospitaldb.* to 'dba'@'localhost';

grant insert, select, update, delete on doctor to 'chief'@'localhost';
grant select, insert on medical_record to 'chief'@'localhost';
grant select, delete on appointment to 'chief'@'localhost';
grant select, update on departments to 'chief'@'localhost';
grant select on appointment_view to 'chief'@'localhost';
grant select on medicine to 'chief'@'localhost';
grant select, insert on recipes to 'chief'@'localhost';
grant select on department_view to 'chief'@'localhost';
grant select on alert_table to 'chief'@'localhost';
grant select on chief_doc_view to 'chief'@'localhost';

flush privileges;

show grants for 'dba'@'localhost';
show grants for 'chief'@'localhost';
show grants for 'patient'@'localhost';
show grants for 'doctor'@'localhost';


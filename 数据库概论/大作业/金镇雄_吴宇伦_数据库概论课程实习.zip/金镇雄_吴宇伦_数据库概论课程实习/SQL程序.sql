/* 触发器 */
delimiter $$
create trigger alert after insert on appointment for each row
begin
	if new.referral = true then 
	  insert into alert_table
      value(new.patient_id, new.doctor_id, new.time);
   end if;
end $$

/* 权限管理 */
drop user if exists 'doctor'@'localhost';
drop user if exists 'patient'@'localhost';
drop user if exists 'dba'@'localhost';
drop user if exists 'chief'@'localhost';
flush privileges;

create user 'dba'@'localhost' identified by 'dba';
create user 'chief'@'localhost' identified by 'chief';
create user 'doctor'@'localhost' identified by 'doctor';
create user 'patient'@'localhost' identified by 'patient';
grant update(email, password, tel_num, specialty) on doctor to 'doctor'@'localhost';
grant select, insert on medical_record to 'doctor'@'localhost';
grant select, delete, update on appointment to 'doctor'@'localhost';
grant insert, select(username), update(password) on login to 'doctor'@'localhost';
grant select on departments to 'doctor'@'localhost';
grant select, insert on doctor to 'doctor'@'localhost';
grant select on appointment_view to 'doctor'@'localhost';
grant select, insert on recipes to 'doctor'@'localhost';
grant select on medicine to 'doctor'@'localhost';
grant select on alert_table to 'doctor'@'localhost';
grant select on dept_doc_alert to 'doctor'@'localhost';
grant select on chief_doc_view to 'doctor'@'localhost';

grant insert, select, update(email,password,tel_num) on patient to 'patient'@'localhost';
grant select on doctor to 'patient'@'localhost';
grant select on medical_record to 'patient'@'localhost';
grant select on departments to 'patient'@'localhost';
grant insert, select, delete on appointment to 'patient'@'localhost';
grant insert,select(username), update(password) on login to 'patient'@'localhost';
grant select on appointment_view to 'patient'@'localhost';
grant select on medicine to 'patient'@'localhost';
grant select on recipes to 'patient'@'localhost';
grant select on dept_doc_alert to 'patient'@'localhost';
grant select on chief_doc_view to 'patient'@'localhost';

grant all on hospitaldb.* to 'dba'@'localhost';

grant insert, select, update, delete on doctor to 'chief'@'localhost';
grant select, insert on medical_record to 'chief'@'localhost';
grant select, delete on appointment to 'chief'@'localhost';
grant select, update on departments to 'chief'@'localhost';
grant select on appointment_view to 'chief'@'localhost';
grant select on medicine to 'chief'@'localhost';
grant select, insert on recipes to 'chief'@'localhost';
grant select on department_view to 'chief'@'localhost';
grant select on alert_table to 'chief'@'localhost';
grant select on chief_doc_view to 'chief'@'localhost';

/* SQL 查询 */
/*
找出2021年1月1日之后来院就诊次数前十的患者，按照就诊次数进行降序排序;
若次数相同，则按照患者姓名拼音次序排序;
*/
select name
from patient 
	natural join 
    (select patient_id, count(*) as record_num
		from medical_record
		where date(diagnosed_time) >= '2021-1-1'
		group by patient_id) as patient_record_num
order by record_num desc, name asc
limit 10;

/*
查找开具病历和处方数量最多的医生的信息，包括医生的姓名、所属科室、开具病历
数量、开具处方数量，按照开具病历和处方进行降序排序，病历数相同的，按照处方
数排序;
*/
select name, department, record_num, recipe_num
from (select doctor_id, name, department
		from doctor) as a
	natural join
    (select doctor_id, count(*) as record_num
		from medical_record
        group by doctor_id) as b
    natural join
    (select doctor_id, count(*) as recipe_num
		from medical_record
        where record_id in (select distinct record_id from recipes)
        group by doctor_id) as c
order by record_num desc, recipe_num desc;

/*
找出在30天内接诊病人数量少于全医院医生平均接诊数量的医生姓名、所属科室;
*/
select name, department
from (select doctor_id, name, department
		from doctor) as a
	natural join
	(select doctor_id, count(*) as patient_num
		from medical_record
		where diagnosed_time > date_sub(curdate(), interval 30 day)
		group by doctor_id
        having patient_num < avg(patient_num)) as b;


/*
找出在14天内接诊过体温高于37.3度的病人的科室;
*/
select department
from doctor as D, appointment as A
where D.doctor_id = A.doctor_id
	and A.temperature > 37.3
    and A.time > date_sub(curdate(), interval 14 day);

/*
找出在7天内所有医生开具的处方中，开具数量总数最少的药物名称，
若存在多种药物的总数相同且最少，则都列出;
*/

select medicine_name
from (select medicine_name, sum(medicine_num) as total_num
		from (select record_id
				from medical_record
				where diagnosed_time > date_sub(curdate(), interval 7 day)) as a
			natural join recipes
		group by medicine_name
		having total_num = min(total_num)) as b;

/*
找出在30天内爽约次数超过2次的患者(系统中存在其预约记录，但是没有相应的病历
和处方)的姓名和身份证号。
*/
select name, id_card_num
from patient
where patient_id in
	(select patient_id
		from appointment
		where finish = false
			and now() > time
			and time > date_sub(curdate(), interval 30 day)
		group by patient_id
        having count(*) > 2);
	
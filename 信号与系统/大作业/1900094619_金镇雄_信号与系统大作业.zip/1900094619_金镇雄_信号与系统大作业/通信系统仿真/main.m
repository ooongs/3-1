clc; clear; close all;

% 参数
data_len = 10000; % 二进制序列长度
Nsamp = 8; % 采样倍数
rolloff = 0.5; % 低通滤波器
EbN0_dB = 1:8;

% 生成二进制随机序列
data_source = round(rand(1,data_len)); 

% bpsk 调制
xmod = (data_source - 1/2) * 2;

% 8倍过采样
xmod_8 = upsample(xmod, Nsamp);

% 基带成型滤波
r_cos = rcosfir(rolloff,[-5, 5], Nsamp, 1, 'sqrt'); % 低通滤波器
send_signal = conv(xmod_8,r_cos,'same'); % 卷积


decode_signal = zeros(1,data_len);
receive_signal = zeros(1,data_len*8);
ymod = zeros(1,data_len);
error = zeros(1,length(EbN0_dB));
BER = zeros(1,length(EbN0_dB));
for s = 1:length(EbN0_dB)
    SNR_dB = EbN0_dB(s) + 10*log10(2) - 10*log10(1);
    SNR = 10^(SNR_dB/10);
    % 初始化
    decode_signal = zeros(1,data_len); 
    % AWGN通道
    %xnoisy = awgn(xmod_8,SNR,'measured');
    xnoisy = send_signal + 1/sqrt(SNR)*randn(1,length(send_signal));
    % 低通滤波
    receive_signal = conv(xnoisy,r_cos,'same'); % 卷积
    % 1/8倍低采样
    ymod = downsample(receive_signal, Nsamp);
    % BPSK 解调 & 统计误码个数
    for i=1:length(ymod)
        if(ymod(i) > 0)
            decode_signal(i) = 1;
        else
            decode_signal(i) = 0;
        end
        if(decode_signal(i) ~= data_source(i))
            error(s) = error(s) + 1; % 误码个数
        end
    end
    % 计算误码率
    BER(s) = error(s) / data_len;
    % 计算理想误码率
    % theory_BER(s) = qfunc(sqrt(2*SNR(s)));
    
end

% 计算理想误码率
theory_BER = berawgn(EbN0_dB,'psk',2,'nondiff');





% SNR=10 信号图
n1 = length(xmod_8);           % t1 = 1:n1;
n2 = length(send_signal);      % t2 = 1:n2;
n3 = length(xnoisy);           % t3 = 1:n3; 
n4 = length(receive_signal);   % t4 = 1:n4;
n5 = length(ymod);              t5 = 1:n5;


figure(1); 
X1 = fft(xmod_8,n1); 
k1 = 0:length(X1)-1; t1 = k1 - (length(X1)/2);
subplot(2,1,1); stem(xmod_8); ylim([-2 2])
title("滤波前发送序列时域波形"); xlabel('t'); ylabel('x(t)');
subplot(2,1,2); plot(t1,abs(fftshift(X1))); ylim([0 1000]);
title("滤波前发送序列幅度频谱"); xlabel('Frequency (rad)'); ylabel('Magnitude');  
%subplot(2,1,3); plot(t1,angle(fftshift(X1)));
%title("滤波前发送序列相位频谱"); ylabel('Phase'); xlabel('Frequency (rad)');

figure(2);
X2 = fft(send_signal,n2); 
k2 = 0:length(X2)-1; t2 = k2 - (length(X2)/2);
subplot(3,1,1);
stem(send_signal); ylim([-2 2])% plot(send_signal); 
title("滤波后的发送序列时域波形"); legend('滤波后发送信号');
subplot(3,1,2); plot(t2,abs(fftshift(X2)));
title("滤波后发送信号幅度频谱"); xlabel('Frequency (rad)'); ylabel('Magnitude');  
%subplot(4,1,3); plot(t2,angle(fftshift(X2)));
%title("滤波后发送信号相位频谱"); ylabel('Phase'); xlabel('Frequency (rad)');
subplot(3,1,3); plot(t1,abs(fftshift(X1)),t2,abs(fftshift(X2)));
title("滤波前与滤波后的发送序列幅度频谱"); xlabel('Frequency (rad)'); ylabel('Magnitude'); 
legend('滤波前发送序列','滤波后发送信号');

figure(3);
X3 = fft(xnoisy,n3); 
k3 = 0:length(X3)-1; t3 = k3 - (length(X3)/2);
subplot(2,1,1);
plot(k2,send_signal,k3,xnoisy); 
title("AWGN通道前后时域波形"); legend('发送信号','AWGN信号');
subplot(2,1,2); plot(t3,abs(fftshift(X3)));
title("AWGN信号幅度频谱"); xlabel('Frequency (rad)'); ylabel('Magnitude');  
%subplot(2,1,3); plot(t3,angle(fftshift(X3)));
%title("发送序列相位频谱"); ylabel('Phase'); xlabel('Frequency (rad)');

figure(4);
X4 = fft(receive_signal,n4);
k4 = 0:length(X4)-1; t4 = k4 - (length(X4)/2);
subplot(4,1,1);
plot(k4,receive_signal); 
title("匹配滤波后收端信号时域波形");
subplot(4,1,2); plot(t4,abs(fftshift(X4)));
title("匹配滤波后收端信号幅度频谱"); xlabel('Frequency (rad)'); ylabel('Magnitude');  
subplot(4,1,3); plot(t3,abs(fftshift(X3))); ylim([0 1000]);
title("匹配滤波前收端信号幅度频谱"); xlabel('Frequency (rad)'); ylabel('Magnitude');  
subplot(4,1,4); plot(t3,abs(fftshift(X3)),t4,abs(fftshift(X4)));
title("匹配滤波前后幅度频谱比较"); legend("匹配滤波前收端信号","匹配滤波后收端信号");
xlabel('Frequency (rad)'); ylabel('Magnitude');  
%subplot(2,1,3); plot(t4,angle(fftshift(X4)));
%title("发送序列相位频谱"); ylabel('Phase'); xlabel('Frequency (rad)');

figure(5);
stem(t5,ymod); 
title("1/8倍低采样");

figure(6);
semilogy(EbN0_dB,BER,'M-X', EbN0_dB, theory_BER, 'k-s'); 
grid on;                                      
axis([0 10 10^-5 10^-1])                      
xlabel('SNR');                     
ylabel('BER');                                  
legend('BPSK仿真误码率','BPSK理论误码率');  

% 画星座图
scatterplot(xmod);
scatterplot(ymod);
function encode=ALaw_PCM_Coding(signal)
    M = max(abs(signal));               % 求S的最大值 
    S = abs((signal/M))*2048;           % 归一化并量化
    encode=zeros(length(signal),8);       % 代码存储矩阵
    
    for i=1:length(signal)
        
        % 极性码 1
        if signal(i)>=0
            encode(i,1)=1;    % 正值
        else
            encode(i,1)=0;    % 负值
        end
        
        % 段落吗 2~4
        if (S(i)>=0 && S(i)<16)
            encode(i,2)=0;encode(i,3)=0;encode(i,4)=0;step=1;start=0;
        else if (16<=S(i)&&S(i)<32)
            encode(i,2)=0;encode(i,3)=0;encode(i,4)=1;step=1;start=16;
        else if (32<=S(i)&&S(i)<64)
            encode(i,2)=0;encode(i,3)=1;encode(i,4)=0;step=2;start=32;
        else if (64<=S(i)&&S(i)<128)
            encode(i,2)=0;encode(i,3)=1;encode(i,4)=1;step=4;start=64;
        else if (128<=S(i)&&S(i)<256)
            encode(i,2)=1;encode(i,3)=0;encode(i,4)=0;step=8;start=128;
        else if (256<=S(i)&&S(i)<512)
            encode(i,2)=1;encode(i,3)=0;encode(i,4)=1;step=16;start=256;
        else if (512<=S(i)&&S(i)<1024)
            encode(i,2)=1;encode(i,3)=1;encode(i,4)=0;step=32;start=512;
        else if (1024<=S(i)&&S(i)<2048)
            encode(i,2)=1;encode(i,3)=1;encode(i,4)=1;step=64;start=1024;
            end
            end
            end
            end
            end
            end
            end
        end
        
        % 段内电平码 5~8
        b=floor((S(i)-start)/step);
        t=dec2bin(b,4)-48;
        encode(i,5:8)=t(1:4);
    end
    encode = reshape(encode', 1, []);   % 从新塑性
end
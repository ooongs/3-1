clc; clear; close all;

% 准备音频样本
info = audioinfo('jazz.wav');
Fs = 44100;                                 % MATLAB 默认的采样频率
audio_start = 3*Fs;                         % 音频样本的start
audio_end = 6*Fs;                           % 音频样本的end
samples = [audio_start,audio_end];          % 音频样本的范围(3秒)
[audio,fs] = audioread('jazz.wav',samples); % 读取音频样本
% sound(audio,fs);                          % 播放音频样本
audio=audio(:,1);                           % 音频样本有两个信道，其中只取一个
len = length(audio);                        % 音频样本长度
max = max(audio);                           % 音频样本的最大值

% 采样：时间连续信号转换为时间离散模拟信号
%samp_fs = 4*fs;                             % 抽样频率至少是原信号频率的2倍
%t_y1 = (len-1)/samp_fs; 
%x1 = 0:t_y1:len;

% 均匀量化（量化级数为8）
uni_pcm = Uniform_PCM(audio);

% 非均匀量化（A律13折）
pcm_encode = ALaw_PCM_Coding(audio);                % PCM 编码
pcm_decode = ALaw_PCM_Decoding(pcm_encode, max);    % PCM 译码
alaw_pcm = pcm_decode;


% 信噪比以及失真度分析
t = (0:len-1)/fs;
p_audio = 0;                                    % 信号功率
k_uni = 0;                                      % 均匀量化的失真度
k_alaw = 0;                                     % 非均匀量化的失真度
for i = 1:length(t)
    p1 = (audio(i))^2;
    k1 = (audio(i)-uni_pcm(i))^2/len;
    k2 = (audio(i)-alaw_pcm(i))^2/len;     
    k_uni = k_uni + k1;
    k_alaw = k_alaw + k2;
    p_audio = p_audio + p1;
end
snr_uni = 10*log10((len*p_audio)/k_uni);
snr_alaw = 10*log10((len*p_audio)/k_alaw);
fprintf('均匀量化失真度是：%.6f\n',k_uni);
fprintf('非均匀量化失真度是：%.6f\n',k_alaw);
fprintf('均匀量化信噪比是：%.6f (dB)\n',snr_uni);
fprintf('非均匀量化信噪比是：%.6f (dB)\n',snr_alaw);

% 写出量化后的音频结果
audiowrite('original.wav',audio,fs);
audiowrite('uni_pcm_result.wav',uni_pcm,fs);
audiowrite('alaw_pcm_result.wav',alaw_pcm,fs);

% 计算原始音频的频域特性
fft_samp = fft(audio,fs);
xf_samp = fs/(len-1);
x_samp = xf_samp*(0:length(fft_samp)-1);

% 计算均匀量化后的频域特性
fft_uni = fft(uni_pcm,fs) ;
xf_uni   = fs/(length(uni_pcm)-1);
x_uni = xf_uni*(0:length(fft_uni)-1);

% 计算非均匀量化后的频域特性
fft_alaw = fft(alaw_pcm,fs) ;
xf_alaw   = fs/(length(alaw_pcm)-1);
x_alaw = xf_alaw*(0:length(fft_alaw)-1);

% 画图

figure; % 时域图及频谱图比较

subplot(211);
plot(t,audio);
title('原始音频信号时域图'); xlabel('时间(s)'); ylabel('幅度');
 
subplot(212);
plot(x_samp,abs(fft_samp));
title('原始音频信号频域图'); xlabel('频率(Hz)'); ylabel('幅值');

figure;
subplot(211)
plot(t,uni_pcm);
title('均匀量化后信号时域图'); xlabel('时间(s)'); ylabel('幅度');

subplot(212)
plot(x_uni,abs(fft_uni)) 
title('均匀量化后信号频域图'); xlabel('频率(Hz)'); ylabel('幅值');

figure;
subplot(211)
plot(t,alaw_pcm);
title('非均匀量化后信号时域图'); xlabel('时间(s)'); ylabel('幅度');

subplot(212)
plot(x_alaw,abs(fft_alaw)) 
title('非均匀量化后信号频域图'); xlabel('频率(Hz)'); ylabel('幅值');

figure; % 波形图比较

subplot(311)
plot(t,audio,'r')
axis([0 3 -1 1]);
title('示例信号波形图');

subplot(312)
plot(t,uni_pcm,'b')
axis([0 3 -1 1]);
title('均匀量化后信号波形图');

subplot(313)
plot(t,alaw_pcm,'g')
axis([0 3 -1 1]);
title('非均匀量化后信号波形图');
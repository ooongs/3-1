function decode=ALaw_PCM_Decoding(encode, max)
    encode=(reshape(encode',8,length(encode)/8))';
    start=[0,16,32,64,128,256,512,1024];
    step=[1 1 2 4 8 16 32 64];
    c=[0 1.5:15.5];
    for i=1:size(encode,1)
        tt = num2str(encode(i,(2:4))); % 段落码
        t=bin2dec(tt)+1;  
        yy = num2str(encode(i,(5:8))); % 段内电平码
        y=bin2dec(yy);
        if y==0
            tmp(i)=start(t)/2048;
        else
            tmp(i)=(start(t)+step(t)*c(y))/2048;
        end
        if encode(i,1)==0                       % 极性码
            decode(i)=-tmp(i);
        else
            decode(i)=tmp(i);
        end
    end
    decode = decode*max;
end
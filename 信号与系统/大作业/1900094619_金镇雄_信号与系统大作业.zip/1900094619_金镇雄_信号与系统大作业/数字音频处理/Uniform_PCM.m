function quant=Uniform_PCM(signal)
    len = length(signal);                   % 样本长度
    M = 8;                                  % 8bit量化
    s_min = min(signal);                    % 样本的最小值
    s_max = max(signal);                    % 样本的最大值
    D = (s_max - s_min) / M;                % 量化间隔
    d = zeros(1,M);                         % 量化间隔端点 
    for i = 1:M
        d(i) = s_min + i * D;
    end

    quant = zeros(1,floor(len));
    step = [s_min-0.0001,d(1:M-1),s_max+0.0001];  % 将量化端点转换成矩阵

    % 均匀量化
    for i = 1:len
        for j = 1:M
            if(step(j) < signal(i) && signal(i) <= step(j + 1))
                % 量化输出电平取为量化间隔的中点
                quant(i) = (step(j) + step(j + 1) ) / 2 ;
            end
        end
    end 
end